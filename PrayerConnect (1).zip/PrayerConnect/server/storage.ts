import {
  users,
  prayerRequests,
  prayerCommitments,
  prayerGroups,
  prayerGroupMembers,
  groupPrayerRequests,
  notifications,
  notificationPreferences,
  wsTokens,
  adminActions,
  frontendEvents,
  prayerRequestFlags,
  type User,
  type UpsertUser,
  type PrayerRequest,
  type InsertPrayerRequest,
  type PrayerGroup,
  type InsertPrayerGroup,
  type PrayerCommitment,
  type InsertPrayerCommitment,
  type PrayerGroupMember,
  type Notification,
  type InsertNotification,
  type NotificationPreferences,
  type InsertNotificationPreferences,
  type WSToken,
  type InsertWSToken,
  type AdminAction,
  type InsertAdminAction,
  type FrontendEvent,
  type InsertFrontendEvent,
  type PrayerRequestFlag,
  type InsertPrayerRequestFlag,
  type UpdatePrayerRequestModeration,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserProfile(id: string, updates: { firstName?: string; lastName?: string; displayName?: string | null; profileImageUrl?: string | null }): Promise<User | undefined>;

  // Prayer request operations
  createPrayerRequest(data: InsertPrayerRequest & { authorId: string }): Promise<PrayerRequest>;
  getPrayerRequests(options?: { limit?: number; offset?: number; category?: string; urgent?: boolean }): Promise<PrayerRequest[]>;
  getPrayerRequestById(id: string): Promise<PrayerRequest | undefined>;
  updatePrayerRequest(id: string, updates: Partial<PrayerRequest>): Promise<PrayerRequest | undefined>;
  getPrayerRequestsByUserId(userId: string): Promise<PrayerRequest[]>;
  getNearbyPrayerRequests(latitude: number, longitude: number, radiusKm?: number): Promise<PrayerRequest[]>;
  getNearbyUsers(latitude: number, longitude: number, radiusKm?: number): Promise<User[]>;

  // Prayer commitment operations
  createPrayerCommitment(data: InsertPrayerCommitment): Promise<PrayerCommitment>;
  getPrayerCommitmentsByUser(userId: string): Promise<PrayerCommitment[]>;
  getPrayerCommitmentsByRequest(requestId: string): Promise<PrayerCommitment[]>;
  getPrayerCommitmentCount(requestId: string): Promise<number>;
  checkUserCommitment(userId: string, requestId: string): Promise<boolean>;

  // Prayer group operations
  createPrayerGroup(data: InsertPrayerGroup & { creatorId: string }): Promise<PrayerGroup>;
  getPrayerGroups(): Promise<PrayerGroup[]>;
  getPrayerGroupById(id: string): Promise<PrayerGroup | undefined>;
  getUserGroups(userId: string): Promise<PrayerGroup[]>;
  addGroupMember(groupId: string, userId: string): Promise<PrayerGroupMember>;
  removeGroupMember(groupId: string, userId: string): Promise<void>;
  getGroupMembers(groupId: string): Promise<PrayerGroupMember[]>;
  addPrayerToGroup(groupId: string, prayerRequestId: string): Promise<void>;

  // Statistics
  getUserStats(userId: string): Promise<{
    prayerCount: number;
    answeredCount: number;
    prayingForCount: number;
    groupCount: number;
  }>;

  // Notification operations
  createNotification(data: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string, options?: { limit?: number; unreadOnly?: boolean }): Promise<Notification[]>;
  markNotificationAsRead(id: string): Promise<void>;
  markAllNotificationsAsRead(userId: string): Promise<void>;
  getUnreadNotificationCount(userId: string): Promise<number>;
  
  // Notification preferences operations
  getUserNotificationPreferences(userId: string): Promise<NotificationPreferences | undefined>;
  updateNotificationPreferences(userId: string, preferences: Partial<NotificationPreferences>): Promise<NotificationPreferences>;
  createDefaultNotificationPreferences(userId: string): Promise<NotificationPreferences>;

  // WebSocket token operations
  createWSToken(data: InsertWSToken): Promise<WSToken>;
  getWSToken(token: string): Promise<WSToken | undefined>;
  deleteWSToken(token: string): Promise<void>;
  cleanupExpiredWSTokens(): Promise<void>;

  // Admin analytics operations
  getAdminStats(): Promise<{
    totalUsers: number;
    totalPrayerRequests: number;
    totalUrgentPrayers: number;
    totalAnsweredPrayers: number;
    totalCommitments: number;
    totalGroups: number;
    activeUsersLastWeek: number;
    newUsersThisWeek: number;
    pendingModerationCount: number;
    flaggedPrayersCount: number;
  }>;
  getAllPrayerRequestsWithDetails(): Promise<any[]>;
  getAllUsersWithActivity(): Promise<any[]>;
  
  // Admin moderation operations
  updatePrayerRequestModeration(id: string, updates: UpdatePrayerRequestModeration, adminUserId: string): Promise<PrayerRequest | undefined>;
  logAdminAction(action: InsertAdminAction): Promise<AdminAction>;
  getAdminActionHistory(options?: { limit?: number; targetId?: string }): Promise<AdminAction[]>;
  
  // Prayer request flag operations
  flagPrayerRequest(data: InsertPrayerRequestFlag): Promise<PrayerRequestFlag>;
  getPrayerRequestFlags(prayerRequestId: string): Promise<PrayerRequestFlag[]>;
  reviewPrayerRequestFlag(flagId: string, status: string, reviewerId: string): Promise<PrayerRequestFlag | undefined>;
  
  // Frontend telemetry operations
  logFrontendEvent(data: InsertFrontendEvent): Promise<FrontendEvent>;
  getFrontendAnalytics(options?: { dateRange?: { start: Date; end: Date }; eventType?: string }): Promise<{
    totalEvents: number;
    uniqueUsers: number;
    popularPages: { path: string; count: number }[];
    errorCount: number;
    featureUsage: { feature: string; count: number }[];
  }>;
  getRecentFrontendErrors(limit?: number): Promise<FrontendEvent[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.email,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserProfile(id: string, updates: { firstName?: string; lastName?: string; displayName?: string | null; profileImageUrl?: string | null }): Promise<User | undefined> {
    const [updated] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updated;
  }

  // Prayer request operations
  async createPrayerRequest(data: InsertPrayerRequest & { authorId: string }): Promise<PrayerRequest> {
    const [prayerRequest] = await db
      .insert(prayerRequests)
      .values(data)
      .returning();
    return prayerRequest;
  }

  async getPrayerRequests(options: { limit?: number; offset?: number; category?: string; urgent?: boolean } = {}): Promise<PrayerRequest[]> {
    // Build WHERE conditions
    const conditions = [];
    if (options.category) {
      conditions.push(eq(prayerRequests.category, options.category as any));
    }
    if (options.urgent) {
      conditions.push(eq(prayerRequests.isUrgent, true));
    }

    const queryBuilder = db
      .select({
        id: prayerRequests.id,
        title: prayerRequests.title,
        description: prayerRequests.description,
        category: prayerRequests.category,
        isUrgent: prayerRequests.isUrgent,
        isAnswered: prayerRequests.isAnswered,
        answeredAt: prayerRequests.answeredAt,
        testimony: prayerRequests.testimony,
        latitude: prayerRequests.latitude,
        longitude: prayerRequests.longitude,
        locationName: prayerRequests.locationName,
        authorId: prayerRequests.authorId,
        createdAt: prayerRequests.createdAt,
        updatedAt: prayerRequests.updatedAt,
        author: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          displayName: users.displayName,
          profileImageUrl: users.profileImageUrl,
        },
        prayerCount: sql<number>`COALESCE(${count(prayerCommitments.id)}, 0)`,
      })
      .from(prayerRequests)
      .leftJoin(users, eq(prayerRequests.authorId, users.id))
      .leftJoin(prayerCommitments, eq(prayerRequests.id, prayerCommitments.prayerRequestId))
      .groupBy(prayerRequests.id, users.id);

    // Apply conditions
    let query = conditions.length > 0 
      ? queryBuilder.where(conditions.length === 1 ? conditions[0] : and(...conditions))
      : queryBuilder;

      // Apply ordering and pagination using type casting to work around complex type inference
    let finalQuery: any = query;
    finalQuery = finalQuery.orderBy(desc(prayerRequests.createdAt));

    if (options.limit) {
      finalQuery = finalQuery.limit(options.limit);
    }
    if (options.offset) {
      finalQuery = finalQuery.offset(options.offset);
    }

    return await finalQuery;
  }

  async getPrayerRequestById(id: string): Promise<PrayerRequest | undefined> {
    const [prayerRequest] = await db
      .select()
      .from(prayerRequests)
      .where(eq(prayerRequests.id, id));
    return prayerRequest;
  }

  async updatePrayerRequest(id: string, updates: Partial<PrayerRequest>): Promise<PrayerRequest | undefined> {
    const [updated] = await db
      .update(prayerRequests)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(prayerRequests.id, id))
      .returning();
    return updated;
  }

  async getPrayerRequestsByUserId(userId: string): Promise<PrayerRequest[]> {
    return await db
      .select()
      .from(prayerRequests)
      .where(eq(prayerRequests.authorId, userId))
      .orderBy(desc(prayerRequests.createdAt));
  }

  async getNearbyPrayerRequests(latitude: number, longitude: number, radiusKm: number = 50): Promise<PrayerRequest[]> {
    // Using PostgreSQL's earth distance functions would be better in production
    // For now, using a simple bounding box calculation
    const latDelta = radiusKm / 111; // Rough conversion: 1 degree lat ≈ 111 km
    const lonDelta = radiusKm / (111 * Math.cos(latitude * Math.PI / 180));

    return await db
      .select()
      .from(prayerRequests)
      .where(
        and(
          sql`${prayerRequests.latitude} BETWEEN ${latitude - latDelta} AND ${latitude + latDelta}`,
          sql`${prayerRequests.longitude} BETWEEN ${longitude - lonDelta} AND ${longitude + lonDelta}`
        )
      )
      .orderBy(desc(prayerRequests.createdAt));
  }

  async getNearbyUsers(latitude: number, longitude: number, radiusKm: number = 50): Promise<User[]> {
    // Find users who have posted prayer requests within the specified radius
    // This is a more inclusive approach that captures all users with location data
    const latDelta = radiusKm / 111; // Rough conversion: 1 degree lat ≈ 111 km
    const lonDelta = radiusKm / (111 * Math.cos(latitude * Math.PI / 180));

    // Get unique users from prayer requests within the radius
    const nearbyUserIds = await db
      .selectDistinct({ authorId: prayerRequests.authorId })
      .from(prayerRequests)
      .where(
        and(
          sql`${prayerRequests.latitude} BETWEEN ${latitude - latDelta} AND ${latitude + latDelta}`,
          sql`${prayerRequests.longitude} BETWEEN ${longitude - lonDelta} AND ${longitude + lonDelta}`,
          sql`${prayerRequests.latitude} IS NOT NULL`,
          sql`${prayerRequests.longitude} IS NOT NULL`
        )
      );

    if (nearbyUserIds.length === 0) {
      return [];
    }

    // Get full user data for these users
    const userIds = nearbyUserIds.map(u => u.authorId);
    return await db
      .select()
      .from(users)
      .where(
        sql`${users.id} IN (${sql.join(userIds.map(id => sql`${id}`), sql`, `)})`
      );
  }

  // Prayer commitment operations
  async createPrayerCommitment(data: InsertPrayerCommitment): Promise<PrayerCommitment> {
    const [commitment] = await db
      .insert(prayerCommitments)
      .values(data)
      .returning();
    return commitment;
  }

  async getPrayerCommitmentsByUser(userId: string): Promise<PrayerCommitment[]> {
    return await db
      .select()
      .from(prayerCommitments)
      .where(eq(prayerCommitments.userId, userId))
      .orderBy(desc(prayerCommitments.createdAt));
  }

  async getPrayerCommitmentsByRequest(requestId: string): Promise<PrayerCommitment[]> {
    return await db
      .select()
      .from(prayerCommitments)
      .where(eq(prayerCommitments.prayerRequestId, requestId));
  }

  async getPrayerCommitmentCount(requestId: string): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(prayerCommitments)
      .where(eq(prayerCommitments.prayerRequestId, requestId));
    return result.count;
  }

  async checkUserCommitment(userId: string, requestId: string): Promise<boolean> {
    const [commitment] = await db
      .select({ id: prayerCommitments.id })
      .from(prayerCommitments)
      .where(
        and(
          eq(prayerCommitments.userId, userId),
          eq(prayerCommitments.prayerRequestId, requestId)
        )
      );
    return !!commitment;
  }

  // Prayer group operations
  async createPrayerGroup(data: InsertPrayerGroup & { creatorId: string }): Promise<PrayerGroup> {
    const [group] = await db
      .insert(prayerGroups)
      .values(data)
      .returning();

    // Add creator as admin member
    await db
      .insert(prayerGroupMembers)
      .values({
        groupId: group.id,
        userId: data.creatorId,
        role: "admin",
      });

    return group;
  }

  async getPrayerGroups(): Promise<PrayerGroup[]> {
    return await db
      .select()
      .from(prayerGroups)
      .where(eq(prayerGroups.isPrivate, false))
      .orderBy(desc(prayerGroups.createdAt));
  }

  async getPrayerGroupById(id: string): Promise<PrayerGroup | undefined> {
    const [group] = await db
      .select()
      .from(prayerGroups)
      .where(eq(prayerGroups.id, id));
    return group;
  }

  async getUserGroups(userId: string): Promise<PrayerGroup[]> {
    return await db
      .select({
        id: prayerGroups.id,
        name: prayerGroups.name,
        description: prayerGroups.description,
        isPrivate: prayerGroups.isPrivate,
        creatorId: prayerGroups.creatorId,
        createdAt: prayerGroups.createdAt,
        updatedAt: prayerGroups.updatedAt,
      })
      .from(prayerGroups)
      .innerJoin(prayerGroupMembers, eq(prayerGroups.id, prayerGroupMembers.groupId))
      .where(eq(prayerGroupMembers.userId, userId))
      .orderBy(desc(prayerGroups.createdAt));
  }

  async addGroupMember(groupId: string, userId: string): Promise<PrayerGroupMember> {
    const [member] = await db
      .insert(prayerGroupMembers)
      .values({ groupId, userId })
      .returning();
    return member;
  }

  async removeGroupMember(groupId: string, userId: string): Promise<void> {
    await db
      .delete(prayerGroupMembers)
      .where(
        and(
          eq(prayerGroupMembers.groupId, groupId),
          eq(prayerGroupMembers.userId, userId)
        )
      );
  }

  async getGroupMembers(groupId: string): Promise<PrayerGroupMember[]> {
    return await db
      .select({
        id: prayerGroupMembers.id,
        groupId: prayerGroupMembers.groupId,
        userId: prayerGroupMembers.userId,
        role: prayerGroupMembers.role,
        joinedAt: prayerGroupMembers.joinedAt,
        user: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
        },
      })
      .from(prayerGroupMembers)
      .innerJoin(users, eq(prayerGroupMembers.userId, users.id))
      .where(eq(prayerGroupMembers.groupId, groupId))
      .orderBy(asc(prayerGroupMembers.joinedAt)) as any;
  }

  async addPrayerToGroup(groupId: string, prayerRequestId: string): Promise<void> {
    await db
      .insert(groupPrayerRequests)
      .values({ groupId, prayerRequestId });
  }

  // Statistics
  async getUserStats(userId: string): Promise<{
    prayerCount: number;
    answeredCount: number;
    prayingForCount: number;
    groupCount: number;
  }> {
    const [prayerCountResult] = await db
      .select({ count: count() })
      .from(prayerRequests)
      .where(eq(prayerRequests.authorId, userId));

    const [answeredCountResult] = await db
      .select({ count: count() })
      .from(prayerRequests)
      .where(
        and(
          eq(prayerRequests.authorId, userId),
          eq(prayerRequests.isAnswered, true)
        )
      );

    const [prayingForCountResult] = await db
      .select({ count: count() })
      .from(prayerCommitments)
      .where(eq(prayerCommitments.userId, userId));

    const [groupCountResult] = await db
      .select({ count: count() })
      .from(prayerGroupMembers)
      .where(eq(prayerGroupMembers.userId, userId));

    return {
      prayerCount: prayerCountResult.count,
      answeredCount: answeredCountResult.count,
      prayingForCount: prayingForCountResult.count,
      groupCount: groupCountResult.count,
    };
  }

  // Notification operations
  async createNotification(data: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values(data)
      .returning();
    return notification;
  }

  async getUserNotifications(userId: string, options: { limit?: number; unreadOnly?: boolean } = {}): Promise<Notification[]> {
    const { limit = 50, unreadOnly = false } = options;
    
    // Build WHERE conditions
    const conditions = [eq(notifications.userId, userId)];
    if (unreadOnly) {
      conditions.push(eq(notifications.isRead, false));
    }

    const queryBuilder = db
      .select()
      .from(notifications)
      .where(conditions.length === 1 ? conditions[0] : and(...conditions));

    // Apply ordering and pagination using type casting to work around complex type inference
    let finalQuery: any = queryBuilder.orderBy(desc(notifications.createdAt));

    if (limit) {
      finalQuery = finalQuery.limit(limit);
    }

    return await finalQuery;
  }

  async markNotificationAsRead(id: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }

  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
    
    return result.count;
  }

  // Notification preferences operations
  async getUserNotificationPreferences(userId: string): Promise<NotificationPreferences | undefined> {
    const [preferences] = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId));
    return preferences;
  }

  async updateNotificationPreferences(userId: string, preferences: Partial<NotificationPreferences>): Promise<NotificationPreferences> {
    const [updated] = await db
      .update(notificationPreferences)
      .set({ ...preferences, updatedAt: new Date() })
      .where(eq(notificationPreferences.userId, userId))
      .returning();
    return updated;
  }

  async createDefaultNotificationPreferences(userId: string): Promise<NotificationPreferences> {
    const [preferences] = await db
      .insert(notificationPreferences)
      .values({ userId })
      .returning();
    return preferences;
  }

  // WebSocket token operations
  async createWSToken(data: InsertWSToken): Promise<WSToken> {
    const [token] = await db
      .insert(wsTokens)
      .values(data)
      .returning();
    return token;
  }

  async getWSToken(token: string): Promise<WSToken | undefined> {
    const [wsToken] = await db
      .select()
      .from(wsTokens)
      .where(eq(wsTokens.token, token))
      .limit(1);
    return wsToken;
  }

  async deleteWSToken(token: string): Promise<void> {
    await db
      .delete(wsTokens)
      .where(eq(wsTokens.token, token));
  }

  async cleanupExpiredWSTokens(): Promise<void> {
    await db
      .delete(wsTokens)
      .where(sql`${wsTokens.expiresAt} < NOW()`);
  }

  // Admin analytics operations
  async getAdminStats(): Promise<{
    totalUsers: number;
    totalPrayerRequests: number;
    totalUrgentPrayers: number;
    totalAnsweredPrayers: number;
    totalCommitments: number;
    totalGroups: number;
    activeUsersLastWeek: number;
    newUsersThisWeek: number;
    pendingModerationCount: number;
    flaggedPrayersCount: number;
  }> {
    const [totalUsers] = await db.select({ count: count() }).from(users);
    const [totalPrayerRequests] = await db.select({ count: count() }).from(prayerRequests);
    const [totalUrgentPrayers] = await db.select({ count: count() }).from(prayerRequests).where(eq(prayerRequests.isUrgent, true));
    const [totalAnsweredPrayers] = await db.select({ count: count() }).from(prayerRequests).where(eq(prayerRequests.isAnswered, true));
    const [totalCommitments] = await db.select({ count: count() }).from(prayerCommitments);
    const [totalGroups] = await db.select({ count: count() }).from(prayerGroups);

    // Users who created prayer requests or made commitments in last 7 days
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const [activeUsersLastWeek] = await db
      .select({ count: sql<number>`COUNT(DISTINCT ${users.id})` })
      .from(users)
      .leftJoin(prayerRequests, eq(users.id, prayerRequests.authorId))
      .leftJoin(prayerCommitments, eq(users.id, prayerCommitments.userId))
      .where(sql`${prayerRequests.createdAt} > ${oneWeekAgo} OR ${prayerCommitments.createdAt} > ${oneWeekAgo}`);

    // Users who joined in last 7 days
    const [newUsersThisWeek] = await db
      .select({ count: count() })
      .from(users)
      .where(sql`${users.createdAt} > ${oneWeekAgo}`);

    const [pendingModeration] = await db.select({ count: count() }).from(prayerRequests).where(eq(prayerRequests.moderationStatus, 'pending'));
    const [flaggedPrayers] = await db.select({ count: count() }).from(prayerRequests).where(sql`${prayerRequests.flaggedCount} > 0`);

    return {
      totalUsers: totalUsers.count,
      totalPrayerRequests: totalPrayerRequests.count,
      totalUrgentPrayers: totalUrgentPrayers.count,
      totalAnsweredPrayers: totalAnsweredPrayers.count,
      totalCommitments: totalCommitments.count,
      totalGroups: totalGroups.count,
      activeUsersLastWeek: activeUsersLastWeek.count,
      newUsersThisWeek: newUsersThisWeek.count,
      pendingModerationCount: pendingModeration.count,
      flaggedPrayersCount: flaggedPrayers.count,
    };
  }

  async getAllPrayerRequestsWithDetails(): Promise<any[]> {
    return await db
      .select({
        id: prayerRequests.id,
        title: prayerRequests.title,
        description: prayerRequests.description,
        category: prayerRequests.category,
        isUrgent: prayerRequests.isUrgent,
        isAnswered: prayerRequests.isAnswered,
        answeredAt: prayerRequests.answeredAt,
        testimony: prayerRequests.testimony,
        locationName: prayerRequests.locationName,
        latitude: prayerRequests.latitude,
        longitude: prayerRequests.longitude,
        moderationStatus: prayerRequests.moderationStatus,
        moderatedBy: prayerRequests.moderatedBy,
        moderatedAt: prayerRequests.moderatedAt,
        moderationReason: prayerRequests.moderationReason,
        flaggedCount: prayerRequests.flaggedCount,
        viewCount: prayerRequests.viewCount,
        createdAt: prayerRequests.createdAt,
        updatedAt: prayerRequests.updatedAt,
        author: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email,
        },
        commitmentCount: sql<number>`COALESCE(${count(prayerCommitments.id)}, 0)`,
      })
      .from(prayerRequests)
      .leftJoin(users, eq(prayerRequests.authorId, users.id))
      .leftJoin(prayerCommitments, eq(prayerRequests.id, prayerCommitments.prayerRequestId))
      .groupBy(prayerRequests.id, users.id)
      .orderBy(desc(prayerRequests.createdAt));
  }

  async getAllUsersWithActivity(): Promise<any[]> {
    return await db
      .select({
        id: users.id,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        createdAt: users.createdAt,
        prayerRequestCount: sql<number>`COUNT(DISTINCT ${prayerRequests.id})`,
        commitmentCount: sql<number>`COUNT(DISTINCT ${prayerCommitments.id})`,
        groupCount: sql<number>`COUNT(DISTINCT ${prayerGroupMembers.groupId})`,
      })
      .from(users)
      .leftJoin(prayerRequests, eq(users.id, prayerRequests.authorId))
      .leftJoin(prayerCommitments, eq(users.id, prayerCommitments.userId))
      .leftJoin(prayerGroupMembers, eq(users.id, prayerGroupMembers.userId))
      .groupBy(users.id)
      .orderBy(desc(users.createdAt));
  }

  // Admin moderation operations
  async updatePrayerRequestModeration(id: string, updates: UpdatePrayerRequestModeration, adminUserId: string): Promise<PrayerRequest | undefined> {
    const updateData: any = {
      moderationStatus: updates.moderationStatus,
      moderatedBy: adminUserId,
      moderatedAt: new Date(),
      updatedAt: new Date(),
    };

    if (updates.moderationReason) {
      updateData.moderationReason = updates.moderationReason;
    }

    const [updatedPrayer] = await db
      .update(prayerRequests)
      .set(updateData)
      .where(eq(prayerRequests.id, id))
      .returning();

    // Log the admin action
    await this.logAdminAction({
      adminUserId,
      action: `${updates.moderationStatus}_prayer`,
      targetType: 'prayer_request',
      targetId: id,
      details: { moderationReason: updates.moderationReason },
    });

    return updatedPrayer;
  }

  async logAdminAction(action: InsertAdminAction): Promise<AdminAction> {
    const [result] = await db
      .insert(adminActions)
      .values(action)
      .returning();
    return result;
  }

  async getAdminActionHistory(options: { limit?: number; targetId?: string } = {}): Promise<AdminAction[]> {
    const { limit = 100, targetId } = options;
    
    if (targetId) {
      return await db
        .select({
          id: adminActions.id,
          adminUserId: adminActions.adminUserId,
          action: adminActions.action,
          targetType: adminActions.targetType,
          targetId: adminActions.targetId,
          details: adminActions.details,
          createdAt: adminActions.createdAt,
          adminUser: {
            id: users.id,
            firstName: users.firstName,
            lastName: users.lastName,
            email: users.email,
          }
        })
        .from(adminActions)
        .leftJoin(users, eq(adminActions.adminUserId, users.id))
        .where(eq(adminActions.targetId, targetId))
        .orderBy(desc(adminActions.createdAt))
        .limit(limit);
    }

    return await db
      .select({
        id: adminActions.id,
        adminUserId: adminActions.adminUserId,
        action: adminActions.action,
        targetType: adminActions.targetType,
        targetId: adminActions.targetId,
        details: adminActions.details,
        createdAt: adminActions.createdAt,
        adminUser: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email,
        }
      })
      .from(adminActions)
      .leftJoin(users, eq(adminActions.adminUserId, users.id))
      .orderBy(desc(adminActions.createdAt))
      .limit(limit);
  }

  // Prayer request flag operations
  async flagPrayerRequest(data: InsertPrayerRequestFlag): Promise<PrayerRequestFlag> {
    const [flag] = await db
      .insert(prayerRequestFlags)
      .values(data)
      .returning();

    // Increment the flagged count on the prayer request
    await db
      .update(prayerRequests)
      .set({ 
        flaggedCount: sql`${prayerRequests.flaggedCount} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(prayerRequests.id, data.prayerRequestId));

    return flag;
  }

  async getPrayerRequestFlags(prayerRequestId: string): Promise<PrayerRequestFlag[]> {
    return await db
      .select({
        id: prayerRequestFlags.id,
        prayerRequestId: prayerRequestFlags.prayerRequestId,
        flaggerUserId: prayerRequestFlags.flaggerUserId,
        reason: prayerRequestFlags.reason,
        details: prayerRequestFlags.details,
        status: prayerRequestFlags.status,
        reviewedBy: prayerRequestFlags.reviewedBy,
        reviewedAt: prayerRequestFlags.reviewedAt,
        createdAt: prayerRequestFlags.createdAt,
        flaggerUser: {
          id: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email,
        }
      })
      .from(prayerRequestFlags)
      .leftJoin(users, eq(prayerRequestFlags.flaggerUserId, users.id))
      .where(eq(prayerRequestFlags.prayerRequestId, prayerRequestId))
      .orderBy(desc(prayerRequestFlags.createdAt));
  }

  async reviewPrayerRequestFlag(flagId: string, status: string, reviewerId: string): Promise<PrayerRequestFlag | undefined> {
    const [updatedFlag] = await db
      .update(prayerRequestFlags)
      .set({
        status,
        reviewedBy: reviewerId,
        reviewedAt: new Date(),
      })
      .where(eq(prayerRequestFlags.id, flagId))
      .returning();

    // Log the admin action
    await this.logAdminAction({
      adminUserId: reviewerId,
      action: 'review_flag',
      targetType: 'prayer_request_flag',
      targetId: flagId,
      details: { newStatus: status },
    });

    return updatedFlag;
  }

  // Frontend telemetry operations
  async logFrontendEvent(data: InsertFrontendEvent): Promise<FrontendEvent> {
    const [event] = await db
      .insert(frontendEvents)
      .values(data)
      .returning();
    return event;
  }

  async getFrontendAnalytics(options: { dateRange?: { start: Date; end: Date }; eventType?: string } = {}): Promise<{
    totalEvents: number;
    uniqueUsers: number;
    popularPages: { path: string; count: number }[];
    errorCount: number;
    featureUsage: { feature: string; count: number }[];
  }> {
    const { dateRange, eventType } = options;

    // Get total events
    const [totalEventsResult] = await db
      .select({ count: count() })
      .from(frontendEvents)
      .where(
        dateRange 
          ? and(
              sql`${frontendEvents.createdAt} >= ${dateRange.start}`,
              sql`${frontendEvents.createdAt} <= ${dateRange.end}`
            )
          : undefined
      );

    // Get unique users
    const [uniqueUsersResult] = await db
      .select({ count: sql<number>`COUNT(DISTINCT ${frontendEvents.userId})` })
      .from(frontendEvents)
      .where(
        and(
          sql`${frontendEvents.userId} IS NOT NULL`,
          dateRange 
            ? and(
                sql`${frontendEvents.createdAt} >= ${dateRange.start}`,
                sql`${frontendEvents.createdAt} <= ${dateRange.end}`
              )
            : undefined
        )
      );

    // Get popular pages
    const popularPages = await db
      .select({
        path: frontendEvents.pagePath,
        count: count(),
      })
      .from(frontendEvents)
      .where(
        and(
          sql`${frontendEvents.pagePath} IS NOT NULL`,
          dateRange 
            ? and(
                sql`${frontendEvents.createdAt} >= ${dateRange.start}`,
                sql`${frontendEvents.createdAt} <= ${dateRange.end}`
              )
            : undefined
        )
      )
      .groupBy(frontendEvents.pagePath)
      .orderBy(desc(count()))
      .limit(10);

    // Get error count
    const [errorCountResult] = await db
      .select({ count: count() })
      .from(frontendEvents)
      .where(
        and(
          eq(frontendEvents.eventType, 'error'),
          dateRange 
            ? and(
                sql`${frontendEvents.createdAt} >= ${dateRange.start}`,
                sql`${frontendEvents.createdAt} <= ${dateRange.end}`
              )
            : undefined
        )
      );

    // Get feature usage
    const featureUsage = await db
      .select({
        feature: sql<string>`${frontendEvents.eventData}->>'feature'`,
        count: count(),
      })
      .from(frontendEvents)
      .where(
        and(
          eq(frontendEvents.eventType, 'feature_usage'),
          sql`${frontendEvents.eventData}->>'feature' IS NOT NULL`,
          dateRange 
            ? and(
                sql`${frontendEvents.createdAt} >= ${dateRange.start}`,
                sql`${frontendEvents.createdAt} <= ${dateRange.end}`
              )
            : undefined
        )
      )
      .groupBy(sql`${frontendEvents.eventData}->>'feature'`)
      .orderBy(desc(count()))
      .limit(10);

    return {
      totalEvents: totalEventsResult.count,
      uniqueUsers: uniqueUsersResult.count,
      popularPages: popularPages.map(p => ({ path: p.path || '', count: p.count })),
      errorCount: errorCountResult.count,
      featureUsage: featureUsage.map(f => ({ feature: f.feature || '', count: f.count })),
    };
  }

  async getRecentFrontendErrors(limit = 50): Promise<FrontendEvent[]> {
    return await db
      .select()
      .from(frontendEvents)
      .where(eq(frontendEvents.eventType, 'error'))
      .orderBy(desc(frontendEvents.createdAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
