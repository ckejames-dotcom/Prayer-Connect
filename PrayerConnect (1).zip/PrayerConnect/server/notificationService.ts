import { Server as SocketIOServer } from "socket.io";
import { Server as HTTPServer } from "http";
import { storage } from "./storage";
import { type InsertNotification, type NotificationPreferences } from "@shared/schema";
import session from "express-session";
import crypto from "crypto";

export class NotificationService {
  private io: SocketIOServer | null = null;
  private userSockets: Map<string, Set<string>> = new Map(); // userId -> Set of socketIds
  private sessionStore: any = null; // Will be set by the server
  private wsTokens: Map<string, { userId: string; expiresAt: number }> = new Map(); // token -> user data

  setSessionStore(store: any) {
    this.sessionStore = store;
  }

  // Generate a secure WebSocket authentication token
  async generateWSToken(userId: string): Promise<string> {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + (5 * 60 * 1000)); // 5 minutes from now
    
    await storage.createWSToken({
      token,
      userId,
      expiresAt,
    });
    
    // Clean up expired tokens periodically
    this.cleanupExpiredTokens();
    
    return token;
  }

  // Validate WebSocket token and return user ID
  private async validateWSToken(token: string): Promise<string | null> {
    const tokenData = await storage.getWSToken(token);
    
    if (!tokenData) {
      return null;
    }
    
    if (new Date() > tokenData.expiresAt) {
      await storage.deleteWSToken(token);
      return null;
    }
    
    // Token is used once for authentication, then deleted
    await storage.deleteWSToken(token);
    return tokenData.userId;
  }

  // Clean up expired tokens
  private async cleanupExpiredTokens() {
    try {
      await storage.cleanupExpiredWSTokens();
    } catch (error) {
      console.error('Error cleaning up expired WebSocket tokens:', error);
    }
  }

  initialize(httpServer: HTTPServer) {
    this.io = new SocketIOServer(httpServer, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });

    this.io.on("connection", (socket) => {
      console.log("User connected:", socket.id);

      socket.on("authenticate", async (token: string) => {
        try {
          // Validate WebSocket token and get user ID
          const userId = await this.validateWSToken(token);
          
          if (!userId) {
            console.log("Authentication failed for socket:", socket.id, "- Invalid or expired token");
            socket.emit("auth_error", { message: "Invalid or expired authentication token" });
            socket.disconnect();
            return;
          }

          console.log("User authenticated:", userId, "Socket:", socket.id);
          
          // Add socket to user's socket set
          if (!this.userSockets.has(userId)) {
            this.userSockets.set(userId, new Set());
          }
          this.userSockets.get(userId)!.add(socket.id);
          
          // Join user to their personal room
          socket.join(`user:${userId}`);
          
          // Store authenticated userId in socket data
          socket.data.userId = userId;
          
          // Confirm successful authentication
          socket.emit("authenticated", { userId });
          
          // Send initial unread count
          try {
            const unreadCount = await storage.getUnreadNotificationCount(userId);
            socket.emit("unread_count_updated", { count: unreadCount });
          } catch (error) {
            console.error("Error sending initial unread count:", error);
          }
        } catch (error) {
          console.error("Error during socket authentication:", error);
          socket.emit("auth_error", { message: "Authentication failed" });
          socket.disconnect();
        }
      });

      socket.on("disconnect", () => {
        console.log("User disconnected:", socket.id);
        
        // Remove socket from user's socket set
        const userId = socket.data.userId;
        if (userId && this.userSockets.has(userId)) {
          this.userSockets.get(userId)!.delete(socket.id);
          if (this.userSockets.get(userId)!.size === 0) {
            this.userSockets.delete(userId);
          }
        }
      });

      socket.on("mark_notification_read", async (notificationId: string) => {
        try {
          await storage.markNotificationAsRead(notificationId);
          
          // Broadcast updated unread count to user
          const userId = socket.data.userId;
          if (userId) {
            const unreadCount = await storage.getUnreadNotificationCount(userId);
            this.sendToUser(userId, "unread_count_updated", { count: unreadCount });
          }
        } catch (error) {
          console.error("Error marking notification as read:", error);
        }
      });

      socket.on("mark_all_notifications_read", async () => {
        try {
          const userId = socket.data.userId;
          if (userId) {
            await storage.markAllNotificationsAsRead(userId);
            this.sendToUser(userId, "unread_count_updated", { count: 0 });
          }
        } catch (error) {
          console.error("Error marking all notifications as read:", error);
        }
      });
    });
  }

  // Send notification to specific user
  async sendToUser(userId: string, event: string, data: any) {
    if (this.io) {
      this.io.to(`user:${userId}`).emit(event, data);
    }
  }

  // Send notification to multiple users
  async sendToUsers(userIds: string[], event: string, data: any) {
    if (this.io) {
      userIds.forEach(userId => {
        this.io!.to(`user:${userId}`).emit(event, data);
      });
    }
  }

  // Create and send a notification
  async createAndSendNotification(data: InsertNotification) {
    try {
      // Check user's notification preferences
      const preferences = await storage.getUserNotificationPreferences(data.userId);
      
      if (!preferences) {
        // Create default preferences if they don't exist
        await storage.createDefaultNotificationPreferences(data.userId);
      }

      // Check if user wants this type of notification
      const shouldSend = this.shouldSendNotification(data.type, preferences);
      
      if (!shouldSend) {
        return; // User has disabled this notification type
      }

      // Create notification in database
      const notification = await storage.createNotification(data);
      
      // Send real-time notification to user
      await this.sendToUser(data.userId, "new_notification", notification);
      
      // Send updated unread count
      const unreadCount = await storage.getUnreadNotificationCount(data.userId);
      await this.sendToUser(data.userId, "unread_count_updated", { count: unreadCount });

      return notification;
    } catch (error) {
      console.error("Error creating and sending notification:", error);
      throw error;
    }
  }

  // Check if notification should be sent based on user preferences
  private shouldSendNotification(type: string, preferences?: NotificationPreferences): boolean {
    if (!preferences) return true; // Send by default if no preferences

    switch (type) {
      case 'urgent_prayer':
        return preferences.urgentPrayers;
      case 'group_update':
        return preferences.groupUpdates;
      case 'prayer_answered':
        return preferences.prayerAnswered;
      case 'new_group_member':
        return preferences.newGroupMembers;
      case 'prayer_commitment':
        return preferences.prayerCommitments;
      default:
        return true;
    }
  }

  // Send urgent prayer alert to nearby users
  async sendUrgentPrayerAlert(prayerRequest: any, nearbyUsers: string[]) {
    const notification = {
      type: 'urgent_prayer' as const,
      title: '🚨 Urgent Prayer Needed',
      message: `${prayerRequest.author?.firstName || 'Someone'} has an urgent prayer request: ${prayerRequest.title}`,
      relatedEntityId: prayerRequest.id,
      relatedEntityType: 'prayer_request'
    };

    // Send to each nearby user
    for (const userId of nearbyUsers) {
      await this.createAndSendNotification({
        ...notification,
        userId
      });
    }
  }

  // Send group update notification
  async sendGroupUpdateNotification(groupId: string, memberIds: string[], title: string, message: string) {
    const notification = {
      type: 'group_update' as const,
      title,
      message,
      relatedEntityId: groupId,
      relatedEntityType: 'group'
    };

    // Send to each group member
    for (const userId of memberIds) {
      await this.createAndSendNotification({
        ...notification,
        userId
      });
    }
  }

  // Send prayer answered notification
  async sendPrayerAnsweredNotification(prayerRequest: any, commitmentUserIds: string[]) {
    const notification = {
      type: 'prayer_answered' as const,
      title: '🙏 Prayer Answered!',
      message: `Great news! The prayer "${prayerRequest.title}" has been answered.`,
      relatedEntityId: prayerRequest.id,
      relatedEntityType: 'prayer_request'
    };

    // Send to all users who committed to pray
    for (const userId of commitmentUserIds) {
      await this.createAndSendNotification({
        ...notification,
        userId
      });
    }
  }

  // Send new group member notification
  async sendNewGroupMemberNotification(groupId: string, newMemberName: string, existingMemberIds: string[]) {
    const notification = {
      type: 'new_group_member' as const,
      title: '👥 New Group Member',
      message: `${newMemberName} has joined your prayer group!`,
      relatedEntityId: groupId,
      relatedEntityType: 'group'
    };

    // Send to existing group members
    for (const userId of existingMemberIds) {
      await this.createAndSendNotification({
        ...notification,
        userId
      });
    }
  }

  // Send prayer commitment notification
  async sendPrayerCommitmentNotification(prayerRequest: any, committerName: string) {
    const notification = {
      type: 'prayer_commitment' as const,
      title: '🤝 Someone is Praying for You',
      message: `${committerName} has committed to pray for your request: "${prayerRequest.title}"`,
      relatedEntityId: prayerRequest.id,
      relatedEntityType: 'prayer_request'
    };

    await this.createAndSendNotification({
      ...notification,
      userId: prayerRequest.authorId
    });
  }

  // Get connected users count
  getConnectedUsersCount(): number {
    return this.userSockets.size;
  }

  // Check if user is online
  isUserOnline(userId: string): boolean {
    return this.userSockets.has(userId) && this.userSockets.get(userId)!.size > 0;
  }

  // Validate session and extract user ID securely
  private async validateSessionAndGetUserId(sessionId: string): Promise<string | null> {
    if (!this.sessionStore || !sessionId) {
      return null;
    }

    return new Promise((resolve) => {
      this.sessionStore.get(sessionId, (err: any, sessionData: any) => {
        if (err || !sessionData) {
          console.log("Session validation failed:", err);
          resolve(null);
          return;
        }

        // Extract user ID from session data
        const userId = sessionData.passport?.user?.id || sessionData.user?.id;
        
        if (!userId) {
          console.log("No user ID found in session");
          resolve(null);
          return;
        }

        resolve(userId);
      });
    });
  }
}

export const notificationService = new NotificationService();