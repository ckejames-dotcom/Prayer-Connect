import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { notificationService } from "./notificationService";
import { insertPrayerRequestSchema, insertPrayerGroupSchema, insertPrayerCommitmentSchema, insertNotificationPreferencesSchema, updatePrayerRequestModerationSchema, insertPrayerRequestFlagSchema, insertFrontendEventSchema, insertAdminActionSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware - now returns session store
  const sessionStore = await setupAuth(app);
  
  // Configure notification service with session store for secure authentication
  notificationService.setSessionStore(sessionStore);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Profile update route
  app.put('/api/users/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { firstName, lastName, displayName, profileImageUrl } = req.body;
      
      const updatedUser = await storage.updateUserProfile(userId, {
        firstName,
        lastName,
        displayName: displayName || null,
        profileImageUrl: profileImageUrl || null,
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Generate a secure WebSocket authentication token
  app.get('/api/auth/ws-token', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // Create a short-lived token (5 minutes) for WebSocket authentication
      const token = await notificationService.generateWSToken(userId);
      res.json({ token });
    } catch (error) {
      console.error("Error generating WebSocket token:", error);
      res.status(500).json({ message: "Failed to generate authentication token" });
    }
  });

  // Prayer request routes
  const MAX_PRAYER_LENGTH = 1000;
  
  // Simple in-memory rate limit tracker
  const prayerTimestamps: { [userId: string]: number } = {};
  const PRAYER_INTERVAL_MS = 60 * 1000; // 1 minute
  
  app.post('/api/prayer-requests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { description } = req.body;
      
      // Rate limit: 1 prayer per minute per user
      const lastPost = prayerTimestamps[userId] || 0;
      const now = Date.now();
      
      if (now - lastPost < PRAYER_INTERVAL_MS) {
        return res.status(429).json({
          error: "You're submitting prayers too quickly. Please wait a moment.",
        });
      }
      
      // Validate prayer content length (1-1000 characters)
      if (
        typeof description !== "string" ||
        description.trim().length === 0 ||
        description.length > MAX_PRAYER_LENGTH
      ) {
        return res.status(400).json({ message: "Prayer must be 1–1000 characters" });
      }
      
      const validatedData = insertPrayerRequestSchema.parse(req.body);
      
      const prayerRequest = await storage.createPrayerRequest({
        ...validatedData,
        authorId: userId,
      });

      // If urgent and has location, send alert to nearby users
      if (prayerRequest.isUrgent && prayerRequest.latitude && prayerRequest.longitude) {
        try {
          console.log(`Processing urgent prayer request: ${prayerRequest.id} at location ${prayerRequest.latitude}, ${prayerRequest.longitude}`);
          
          const nearbyUsers = await storage.getNearbyUsers(
            parseFloat(prayerRequest.latitude), 
            parseFloat(prayerRequest.longitude), 
            25 // 25km radius
          );
          
          console.log(`Found ${nearbyUsers.length} nearby users for urgent prayer alert`);
          
          // Get user IDs (excluding the author)
          const nearbyUserIds = nearbyUsers
            .map(user => user.id)
            .filter(id => id !== userId);
          
          console.log(`Filtered to ${nearbyUserIds.length} users to notify (excluding author)`);
          
          // For testing: if no nearby users found, create a test notification for the author
          if (nearbyUserIds.length === 0) {
            console.log("No nearby users found - creating test notification for author");
            const author = await storage.getUser(userId);
            await notificationService.createAndSendNotification({
              userId,
              type: 'urgent_prayer',
              title: '🚨 Test: Your Urgent Prayer Was Posted',
              message: `Your urgent prayer request "${prayerRequest.title}" has been posted and would alert nearby users if any exist.`,
              relatedEntityId: prayerRequest.id,
              relatedEntityType: 'prayer_request'
            });
            console.log("Test notification created for author");
          }

          // Get the author info for the notification
          const author = await storage.getUser(userId);
          const enhancedPrayerRequest = {
            ...prayerRequest,
            author
          };

          if (nearbyUserIds.length > 0) {
            await notificationService.sendUrgentPrayerAlert(enhancedPrayerRequest, nearbyUserIds);
          }
        } catch (notificationError) {
          console.error("Error sending urgent prayer alert:", notificationError);
          // Don't fail the request if notification fails
        }
      }
      
      // Update rate limit timestamp after successful creation
      prayerTimestamps[userId] = Date.now();
      
      res.json(prayerRequest);
    } catch (err) {
      console.error("Prayer save error:", err);
      return res.status(500).json({ error: "Something went wrong. Please try again later." });
    }
  });

  app.get('/api/prayer-requests', async (req, res) => {
    try {
      const { limit, offset, category, urgent } = req.query;
      const options = {
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
        category: category as string,
        urgent: urgent === 'true',
      };
      
      const prayerRequests = await storage.getPrayerRequests(options);
      res.json(prayerRequests);
    } catch (error) {
      console.error("Error fetching prayer requests:", error);
      res.status(500).json({ message: "Failed to fetch prayer requests" });
    }
  });

  app.get('/api/prayer-requests/nearby', async (req, res) => {
    try {
      const { lat, lng, radius } = req.query;
      if (!lat || !lng) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }
      
      const prayerRequests = await storage.getNearbyPrayerRequests(
        parseFloat(lat as string),
        parseFloat(lng as string),
        radius ? parseInt(radius as string) : undefined
      );
      res.json(prayerRequests);
    } catch (error) {
      console.error("Error fetching nearby prayer requests:", error);
      res.status(500).json({ message: "Failed to fetch nearby prayer requests" });
    }
  });

  app.get('/api/prayer-requests/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const prayerRequests = await storage.getPrayerRequestsByUserId(userId);
      res.json(prayerRequests);
    } catch (error) {
      console.error("Error fetching user prayer requests:", error);
      res.status(500).json({ message: "Failed to fetch user prayer requests" });
    }
  });

  app.get('/api/prayer-requests/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const prayerRequest = await storage.getPrayerRequestById(id);
      if (!prayerRequest) {
        return res.status(404).json({ message: "Prayer request not found" });
      }
      res.json(prayerRequest);
    } catch (error) {
      console.error("Error fetching prayer request:", error);
      res.status(500).json({ message: "Failed to fetch prayer request" });
    }
  });

  app.put('/api/prayer-requests/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify ownership
      const existing = await storage.getPrayerRequestById(id);
      if (!existing || existing.authorId !== userId) {
        return res.status(404).json({ message: "Prayer request not found" });
      }
      
      const updated = await storage.updatePrayerRequest(id, req.body);
      res.json(updated);
    } catch (error) {
      console.error("Error updating prayer request:", error);
      res.status(400).json({ message: "Failed to update prayer request" });
    }
  });

  // Prayer commitment routes
  app.post('/api/prayer-commitments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { prayerRequestId } = req.body;
      
      // Check if already committed
      const existing = await storage.checkUserCommitment(userId, prayerRequestId);
      if (existing) {
        return res.status(400).json({ message: "Already committed to pray for this request" });
      }
      
      const commitment = await storage.createPrayerCommitment({
        userId,
        prayerRequestId,
      });
      
      res.json(commitment);
    } catch (error) {
      console.error("Error creating prayer commitment:", error);
      res.status(400).json({ message: "Failed to commit to prayer" });
    }
  });

  // Alternative endpoint for easier frontend usage
  app.post('/api/prayer-requests/:id/commit', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const prayerRequestId = req.params.id;
      
      // Check if already committed
      const existing = await storage.checkUserCommitment(userId, prayerRequestId);
      if (existing) {
        return res.status(400).json({ message: "Already committed to pray for this request" });
      }
      
      const commitment = await storage.createPrayerCommitment({
        userId,
        prayerRequestId,
      });

      // Send notification to prayer request author
      try {
        const prayerRequest = await storage.getPrayerRequestById(prayerRequestId);
        const committer = await storage.getUser(userId);
        
        if (prayerRequest && committer) {
          const committerName = `${committer.firstName || ''} ${committer.lastName || ''}`.trim() || 'Someone';
          await notificationService.sendPrayerCommitmentNotification(prayerRequest, committerName);
        }
      } catch (notificationError) {
        console.error("Error sending prayer commitment notification:", notificationError);
        // Don't fail the request if notification fails
      }
      
      res.json(commitment);
    } catch (error) {
      console.error("Error creating prayer commitment:", error);
      res.status(400).json({ message: "Failed to commit to prayer" });
    }
  });

  app.get('/api/prayer-commitments/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const commitments = await storage.getPrayerCommitmentsByUser(userId);
      res.json(commitments);
    } catch (error) {
      console.error("Error fetching user commitments:", error);
      res.status(500).json({ message: "Failed to fetch commitments" });
    }
  });

  app.get('/api/prayer-commitments/count/:requestId', async (req, res) => {
    try {
      const { requestId } = req.params;
      const count = await storage.getPrayerCommitmentCount(requestId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching commitment count:", error);
      res.status(500).json({ message: "Failed to fetch commitment count" });
    }
  });

  // Prayer group routes
  app.post('/api/prayer-groups', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertPrayerGroupSchema.parse(req.body);
      
      const group = await storage.createPrayerGroup({
        ...validatedData,
        creatorId: userId,
      });
      
      res.json(group);
    } catch (error) {
      console.error("Error creating prayer group:", error);
      res.status(400).json({ message: "Failed to create prayer group" });
    }
  });

  app.get('/api/prayer-groups', async (req, res) => {
    try {
      const groups = await storage.getPrayerGroups();
      res.json(groups);
    } catch (error) {
      console.error("Error fetching prayer groups:", error);
      res.status(500).json({ message: "Failed to fetch prayer groups" });
    }
  });

  app.get('/api/prayer-groups/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const groups = await storage.getUserGroups(userId);
      res.json(groups);
    } catch (error) {
      console.error("Error fetching user groups:", error);
      res.status(500).json({ message: "Failed to fetch user groups" });
    }
  });

  app.post('/api/prayer-groups/:id/join', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Get existing group members before adding new member
      const existingMembers = await storage.getGroupMembers(id);
      const existingMemberIds = existingMembers.map(member => member.userId).filter(uid => uid !== userId);
      
      const member = await storage.addGroupMember(id, userId);

      // Send notification to existing group members
      try {
        const newMember = await storage.getUser(userId);
        if (newMember && existingMemberIds.length > 0) {
          const newMemberName = `${newMember.firstName || ''} ${newMember.lastName || ''}`.trim() || 'Someone';
          await notificationService.sendNewGroupMemberNotification(id, newMemberName, existingMemberIds);
        }
      } catch (notificationError) {
        console.error("Error sending new group member notification:", notificationError);
        // Don't fail the request if notification fails
      }
      
      res.json(member);
    } catch (error) {
      console.error("Error joining prayer group:", error);
      res.status(400).json({ message: "Failed to join prayer group" });
    }
  });

  app.get('/api/prayer-groups/:id/members', async (req, res) => {
    try {
      const { id } = req.params;
      const members = await storage.getGroupMembers(id);
      res.json(members);
    } catch (error) {
      console.error("Error fetching group members:", error);
      res.status(500).json({ message: "Failed to fetch group members" });
    }
  });

  // User statistics
  app.get('/api/users/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { limit, unreadOnly } = req.query;
      
      const notifications = await storage.getUserNotifications(userId, {
        limit: limit ? parseInt(limit as string) : undefined,
        unreadOnly: unreadOnly === 'true',
      });
      
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.get('/api/notifications/unread-count', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadNotificationCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread notification count:", error);
      res.status(500).json({ message: "Failed to fetch unread notification count" });
    }
  });

  app.put('/api/notifications/:id/read', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationAsRead(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.put('/api/notifications/read-all', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.markAllNotificationsAsRead(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  // Notification preferences routes
  app.get('/api/notification-preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let preferences = await storage.getUserNotificationPreferences(userId);
      
      if (!preferences) {
        preferences = await storage.createDefaultNotificationPreferences(userId);
      }
      
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching notification preferences:", error);
      res.status(500).json({ message: "Failed to fetch notification preferences" });
    }
  });

  app.put('/api/notification-preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertNotificationPreferencesSchema.parse(req.body);
      
      const preferences = await storage.updateNotificationPreferences(userId, validatedData);
      res.json(preferences);
    } catch (error) {
      console.error("Error updating notification preferences:", error);
      res.status(400).json({ message: "Failed to update notification preferences" });
    }
  });

  // Admin routes for analytics and monitoring - SECURE with proper role checking
  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Strict admin authorization check
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to access analytics" });
      }
      
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get('/api/admin/prayer-requests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Strict admin authorization check
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to access all prayer requests" });
      }
      
      const prayerRequests = await storage.getAllPrayerRequestsWithDetails();
      res.json(prayerRequests);
    } catch (error) {
      console.error("Error fetching admin prayer requests:", error);
      res.status(500).json({ message: "Failed to fetch prayer requests" });
    }
  });

  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Strict admin authorization check
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to access user data" });
      }
      
      const users = await storage.getAllUsersWithActivity();
      res.json(users);
    } catch (error) {
      console.error("Error fetching admin users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Enhanced admin moderation routes
  app.patch('/api/admin/prayer-requests/:id/moderation', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required for moderation" });
      }
      
      const { id } = req.params;
      const validatedData = updatePrayerRequestModerationSchema.parse(req.body);
      
      const updatedPrayer = await storage.updatePrayerRequestModeration(id, validatedData, userId);
      
      if (!updatedPrayer) {
        return res.status(404).json({ message: "Prayer request not found" });
      }
      
      res.json(updatedPrayer);
    } catch (error) {
      console.error("Error updating prayer request moderation:", error);
      res.status(500).json({ message: "Failed to update moderation status" });
    }
  });

  // Admin action history
  app.get('/api/admin/actions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to view action history" });
      }
      
      const { limit, targetId } = req.query;
      const options = {
        limit: limit ? parseInt(limit as string) : undefined,
        targetId: targetId as string,
      };
      
      const actions = await storage.getAdminActionHistory(options);
      res.json(actions);
    } catch (error) {
      console.error("Error fetching admin action history:", error);
      res.status(500).json({ message: "Failed to fetch action history" });
    }
  });

  // Prayer request flag operations
  app.post('/api/prayer-requests/:id/flag', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const validatedData = insertPrayerRequestFlagSchema.parse({
        ...req.body,
        prayerRequestId: id,
        flaggerUserId: userId,
      });
      
      const flag = await storage.flagPrayerRequest(validatedData);
      res.json(flag);
    } catch (error) {
      console.error("Error flagging prayer request:", error);
      res.status(500).json({ message: "Failed to flag prayer request" });
    }
  });

  app.get('/api/admin/prayer-requests/:id/flags', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to view flags" });
      }
      
      const { id } = req.params;
      const flags = await storage.getPrayerRequestFlags(id);
      res.json(flags);
    } catch (error) {
      console.error("Error fetching prayer request flags:", error);
      res.status(500).json({ message: "Failed to fetch flags" });
    }
  });

  app.patch('/api/admin/flags/:flagId/review', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to review flags" });
      }
      
      const { flagId } = req.params;
      const { status } = req.body;
      
      if (!['approved', 'rejected', 'under_review'].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const updatedFlag = await storage.reviewPrayerRequestFlag(flagId, status, userId);
      
      if (!updatedFlag) {
        return res.status(404).json({ message: "Flag not found" });
      }
      
      res.json(updatedFlag);
    } catch (error) {
      console.error("Error reviewing flag:", error);
      res.status(500).json({ message: "Failed to review flag" });
    }
  });

  // Frontend telemetry routes
  app.post('/api/telemetry/event', async (req, res) => {
    try {
      const validatedData = insertFrontendEventSchema.parse(req.body);
      const event = await storage.logFrontendEvent(validatedData);
      res.json(event);
    } catch (error) {
      console.error("Error logging frontend event:", error);
      res.status(500).json({ message: "Failed to log event" });
    }
  });

  app.get('/api/admin/analytics/frontend', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to view analytics" });
      }
      
      const { startDate, endDate, eventType } = req.query;
      const options: any = {};
      
      if (startDate && endDate) {
        options.dateRange = {
          start: new Date(startDate as string),
          end: new Date(endDate as string),
        };
      }
      
      if (eventType) {
        options.eventType = eventType as string;
      }
      
      const analytics = await storage.getFrontendAnalytics(options);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching frontend analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.get('/api/admin/errors/frontend', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Admin privileges required to view errors" });
      }
      
      const { limit } = req.query;
      const errors = await storage.getRecentFrontendErrors(
        limit ? parseInt(limit as string) : undefined
      );
      res.json(errors);
    } catch (error) {
      console.error("Error fetching frontend errors:", error);
      res.status(500).json({ message: "Failed to fetch errors" });
    }
  });

  // Production error handler - catches unhandled errors
  if (process.env.NODE_ENV === "production") {
    app.use((err: any, req: any, res: any, next: any) => {
      console.error("Server error:", err);
      res.status(500).json({ error: "Internal server error" });
    });
  }

  const httpServer = createServer(app);
  
  // Initialize WebSocket for real-time notifications
  notificationService.initialize(httpServer);
  
  return httpServer;
}
