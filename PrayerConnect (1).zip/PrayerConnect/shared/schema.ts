import { sql, relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  boolean,
  integer,
  decimal,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  displayName: varchar("display_name"),
  profileImageUrl: varchar("profile_image_url"),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Prayer categories enum
export const prayerCategoryEnum = pgEnum('prayer_category', ['Family', 'Health', 'Work', 'Other']);

// Moderation status enum
export const moderationStatusEnum = pgEnum('moderation_status', ['pending', 'approved', 'rejected', 'flagged']);

// Prayer visibility enum
export const prayerVisibilityEnum = pgEnum('prayer_visibility', ['public', 'private']);

// Frontend event types enum
export const frontendEventTypeEnum = pgEnum('frontend_event_type', ['page_view', 'prayer_request_create', 'prayer_commitment', 'group_join', 'search', 'map_interaction', 'error', 'feature_usage']);

// Prayer requests table
export const prayerRequests = pgTable("prayer_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 255 }).notNull(),
  description: varchar("description", { length: 1000 }).notNull(),
  category: prayerCategoryEnum("category").notNull(),
  isUrgent: boolean("is_urgent").default(false),
  isAnswered: boolean("is_answered").default(false),
  answeredAt: timestamp("answered_at"),
  testimony: text("testimony"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  locationName: varchar("location_name"),
  authorId: varchar("author_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  // Visibility setting
  visibility: prayerVisibilityEnum("visibility").default('public'),
  // Moderation fields
  moderationStatus: moderationStatusEnum("moderation_status").default('pending'),
  moderatedBy: varchar("moderated_by").references(() => users.id),
  moderatedAt: timestamp("moderated_at"),
  moderationReason: text("moderation_reason"),
  flaggedCount: integer("flagged_count").default(0),
  // Engagement tracking
  viewCount: integer("view_count").default(0),
  // Audit fields
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Prayer commitments table (when users commit to pray for others)
export const prayerCommitments = pgTable("prayer_commitments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  prayerRequestId: varchar("prayer_request_id").notNull().references(() => prayerRequests.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_prayer_commitments_request").on(table.prayerRequestId),
  index("idx_prayer_commitments_user").on(table.userId),
]);

// Prayer groups table
export const prayerGroups = pgTable("prayer_groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isPrivate: boolean("is_private").default(false),
  creatorId: varchar("creator_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Prayer group members table
export const prayerGroupMembers = pgTable("prayer_group_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull().references(() => prayerGroups.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  role: varchar("role").default("member"), // member, moderator, admin
  joinedAt: timestamp("joined_at").defaultNow(),
}, (table) => [
  index("idx_group_members_group").on(table.groupId),
  index("idx_group_members_user").on(table.userId),
]);

// Group prayer requests table
export const groupPrayerRequests = pgTable("group_prayer_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull().references(() => prayerGroups.id, { onDelete: 'cascade' }),
  prayerRequestId: varchar("prayer_request_id").notNull().references(() => prayerRequests.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  prayerRequests: many(prayerRequests),
  prayerCommitments: many(prayerCommitments),
  createdGroups: many(prayerGroups),
  groupMemberships: many(prayerGroupMembers),
}));

export const prayerRequestsRelations = relations(prayerRequests, ({ one, many }) => ({
  author: one(users, {
    fields: [prayerRequests.authorId],
    references: [users.id],
  }),
  moderator: one(users, {
    fields: [prayerRequests.moderatedBy],
    references: [users.id],
  }),
  commitments: many(prayerCommitments),
  groupAssignments: many(groupPrayerRequests),
  flags: many(prayerRequestFlags),
}));

export const prayerCommitmentsRelations = relations(prayerCommitments, ({ one }) => ({
  prayerRequest: one(prayerRequests, {
    fields: [prayerCommitments.prayerRequestId],
    references: [prayerRequests.id],
  }),
  user: one(users, {
    fields: [prayerCommitments.userId],
    references: [users.id],
  }),
}));

export const prayerGroupsRelations = relations(prayerGroups, ({ one, many }) => ({
  creator: one(users, {
    fields: [prayerGroups.creatorId],
    references: [users.id],
  }),
  members: many(prayerGroupMembers),
  prayerRequests: many(groupPrayerRequests),
}));

export const prayerGroupMembersRelations = relations(prayerGroupMembers, ({ one }) => ({
  group: one(prayerGroups, {
    fields: [prayerGroupMembers.groupId],
    references: [prayerGroups.id],
  }),
  user: one(users, {
    fields: [prayerGroupMembers.userId],
    references: [users.id],
  }),
}));

export const groupPrayerRequestsRelations = relations(groupPrayerRequests, ({ one }) => ({
  group: one(prayerGroups, {
    fields: [groupPrayerRequests.groupId],
    references: [prayerGroups.id],
  }),
  prayerRequest: one(prayerRequests, {
    fields: [groupPrayerRequests.prayerRequestId],
    references: [prayerRequests.id],
  }),
}));

// Insert schemas
export const insertPrayerRequestSchema = createInsertSchema(prayerRequests).omit({
  id: true,
  authorId: true,
  moderatedBy: true,
  moderatedAt: true,
  moderationReason: true,
  flaggedCount: true,
  viewCount: true,
  createdAt: true,
  updatedAt: true,
});

// Admin update schema for prayer requests
export const updatePrayerRequestModerationSchema = createInsertSchema(prayerRequests).pick({
  moderationStatus: true,
  moderationReason: true,
}).extend({
  moderationReason: z.string().optional(),
});

export type UpdatePrayerRequestModeration = z.infer<typeof updatePrayerRequestModerationSchema>;

export const insertPrayerGroupSchema = createInsertSchema(prayerGroups).omit({
  id: true,
  creatorId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPrayerCommitmentSchema = createInsertSchema(prayerCommitments).omit({
  id: true,
  createdAt: true,
});

// Notification types enum
export const notificationTypeEnum = pgEnum('notification_type', [
  'urgent_prayer', 
  'group_update', 
  'prayer_answered', 
  'new_group_member',
  'prayer_commitment'
]);

// Notifications table
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  type: notificationTypeEnum("type").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  relatedEntityId: varchar("related_entity_id"), // ID of prayer request, group, etc.
  relatedEntityType: varchar("related_entity_type"), // 'prayer_request', 'group', etc.
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_notifications_user").on(table.userId),
  index("idx_notifications_read").on(table.isRead),
  index("idx_notifications_created").on(table.createdAt),
]);

// Notification preferences table
export const notificationPreferences = pgTable("notification_preferences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }).unique(),
  urgentPrayers: boolean("urgent_prayers").default(true),
  groupUpdates: boolean("group_updates").default(true),
  prayerAnswered: boolean("prayer_answered").default(true),
  newGroupMembers: boolean("new_group_members").default(true),
  prayerCommitments: boolean("prayer_commitments").default(true),
  pushEnabled: boolean("push_enabled").default(false),
  emailEnabled: boolean("email_enabled").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// WebSocket tokens table for secure authentication
export const wsTokens = pgTable("ws_tokens", {
  token: varchar("token").primaryKey(), // 64-character hex token
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_ws_tokens_user").on(table.userId),
  index("idx_ws_tokens_expires").on(table.expiresAt),
]);

// Admin actions audit log
export const adminActions = pgTable("admin_actions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  adminUserId: varchar("admin_user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  action: varchar("action", { length: 100 }).notNull(), // 'approve_prayer', 'reject_prayer', 'delete_user', etc.
  targetType: varchar("target_type", { length: 50 }).notNull(), // 'prayer_request', 'user', 'group', etc.
  targetId: varchar("target_id").notNull(),
  details: jsonb("details"), // Additional context about the action
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_admin_actions_user").on(table.adminUserId),
  index("idx_admin_actions_target").on(table.targetType, table.targetId),
  index("idx_admin_actions_created").on(table.createdAt),
]);

// Frontend telemetry for impact analysis
export const frontendEvents = pgTable("frontend_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }), // nullable for anonymous events
  sessionId: varchar("session_id").notNull(), // track sessions
  eventType: frontendEventTypeEnum("event_type").notNull(),
  eventData: jsonb("event_data"), // flexible data storage
  pagePath: varchar("page_path"),
  userAgent: text("user_agent"),
  ipAddress: varchar("ip_address"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_frontend_events_user").on(table.userId),
  index("idx_frontend_events_session").on(table.sessionId),
  index("idx_frontend_events_type").on(table.eventType),
  index("idx_frontend_events_created").on(table.createdAt),
]);

// Prayer request flags (for user reporting)
export const prayerRequestFlags = pgTable("prayer_request_flags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  prayerRequestId: varchar("prayer_request_id").notNull().references(() => prayerRequests.id, { onDelete: 'cascade' }),
  flaggerUserId: varchar("flagger_user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  reason: varchar("reason", { length: 100 }).notNull(), // 'inappropriate', 'spam', 'offensive', etc.
  details: text("details"),
  status: varchar("status", { length: 20 }).default('pending'), // 'pending', 'reviewed', 'dismissed'
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_prayer_flags_request").on(table.prayerRequestId),
  index("idx_prayer_flags_flagger").on(table.flaggerUserId),
  index("idx_prayer_flags_status").on(table.status),
]);

// Relations for notifications
export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const notificationPreferencesRelations = relations(notificationPreferences, ({ one }) => ({
  user: one(users, {
    fields: [notificationPreferences.userId],
    references: [users.id],
  }),
}));

// Update users relations to include notifications and new admin tables
export const usersRelationsUpdated = relations(users, ({ many }) => ({
  prayerRequests: many(prayerRequests),
  prayerCommitments: many(prayerCommitments),
  createdGroups: many(prayerGroups),
  groupMemberships: many(prayerGroupMembers),
  notifications: many(notifications),
  notificationPreferences: many(notificationPreferences),
  adminActions: many(adminActions),
  frontendEvents: many(frontendEvents),
  flaggedPrayerRequests: many(prayerRequestFlags),
}));

// Admin actions relations
export const adminActionsRelations = relations(adminActions, ({ one }) => ({
  adminUser: one(users, {
    fields: [adminActions.adminUserId],
    references: [users.id],
  }),
}));

// Frontend events relations
export const frontendEventsRelations = relations(frontendEvents, ({ one }) => ({
  user: one(users, {
    fields: [frontendEvents.userId],
    references: [users.id],
  }),
}));

// Prayer request flags relations
export const prayerRequestFlagsRelations = relations(prayerRequestFlags, ({ one }) => ({
  prayerRequest: one(prayerRequests, {
    fields: [prayerRequestFlags.prayerRequestId],
    references: [prayerRequests.id],
  }),
  flaggerUser: one(users, {
    fields: [prayerRequestFlags.flaggerUserId],
    references: [users.id],
  }),
  reviewer: one(users, {
    fields: [prayerRequestFlags.reviewedBy],
    references: [users.id],
  }),
}));

// Insert schemas for notifications
export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Insert schemas for new admin/telemetry tables
export const insertAdminActionSchema = createInsertSchema(adminActions).omit({
  id: true,
  createdAt: true,
});

export const insertFrontendEventSchema = createInsertSchema(frontendEvents).omit({
  id: true,
  createdAt: true,
});

export const insertPrayerRequestFlagSchema = createInsertSchema(prayerRequestFlags).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type PrayerRequest = typeof prayerRequests.$inferSelect;
export type InsertPrayerRequest = z.infer<typeof insertPrayerRequestSchema>;
export type PrayerGroup = typeof prayerGroups.$inferSelect;
export type InsertPrayerGroup = z.infer<typeof insertPrayerGroupSchema>;
export type PrayerCommitment = typeof prayerCommitments.$inferSelect;
export type InsertPrayerCommitment = z.infer<typeof insertPrayerCommitmentSchema>;
export type PrayerGroupMember = typeof prayerGroupMembers.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;
export type WSToken = typeof wsTokens.$inferSelect;
export type InsertWSToken = typeof wsTokens.$inferInsert;

// New admin/telemetry types
export type AdminAction = typeof adminActions.$inferSelect;
export type InsertAdminAction = z.infer<typeof insertAdminActionSchema>;
export type FrontendEvent = typeof frontendEvents.$inferSelect;
export type InsertFrontendEvent = z.infer<typeof insertFrontendEventSchema>;
export type PrayerRequestFlag = typeof prayerRequestFlags.$inferSelect;
export type InsertPrayerRequestFlag = z.infer<typeof insertPrayerRequestFlagSchema>;
