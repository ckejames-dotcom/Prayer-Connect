# PrayTogether

## Overview

PrayTogether is a full-stack web application that connects believers worldwide through prayer requests, location-based prayer mapping, and dedicated prayer groups. The platform allows users to share prayer requests, commit to praying for others, join prayer groups, and visualize prayer needs on an interactive map. Built with a modern TypeScript stack, the application features a React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Component Structure**: Modular component architecture with reusable UI components and page-specific components

### Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API server
- **Database ORM**: Drizzle ORM for type-safe database operations with PostgreSQL
- **Authentication**: Replit's OpenID Connect (OIDC) authentication system with Passport.js
- **Session Management**: Express sessions with PostgreSQL session store using connect-pg-simple
- **API Design**: RESTful endpoints with consistent error handling and request/response patterns
- **File Structure**: Modular separation of concerns with dedicated files for routes, storage layer, and database configuration

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Neon Database as the serverless provider
- **Schema Management**: Drizzle ORM with migrations stored in `/migrations` directory
- **Database Tables**: Users, prayer requests, prayer commitments, prayer groups, group members, and session storage
- **Location Data**: Latitude/longitude coordinates stored for mapping functionality
- **Data Validation**: Zod schemas shared between frontend and backend for consistent validation

### Authentication and Authorization
- **Provider**: Replit's OIDC authentication system for seamless integration with Replit platform
- **Session Storage**: Server-side sessions stored in PostgreSQL with configurable TTL
- **Middleware**: Authentication middleware protecting API endpoints
- **User Management**: Automatic user creation/update on authentication with profile data sync

### External Dependencies
- **Database**: Neon Database (serverless PostgreSQL)
- **Authentication**: Replit OIDC service
- **Mapping**: Placeholder MapComponent ready for integration with mapping services like Leaflet or Mapbox
- **UI Components**: Radix UI primitives for accessible component foundation
- **Icons**: Font Awesome for consistent iconography throughout the application
- **Fonts**: Google Fonts integration for typography (Inter, DM Sans, Fira Code, Geist Mono, Architects Daughter)

### Development and Build Tools
- **Build System**: Vite for fast development and optimized production builds
- **TypeScript**: Full TypeScript support across frontend and backend
- **Development Plugins**: Replit-specific plugins for error overlay, cartographer, and dev banner
- **Code Quality**: ESBuild for backend bundling and TypeScript compilation
- **Path Aliases**: Configured path mapping for clean imports (@/, @shared/, @assets/)

The application follows a modern full-stack architecture with clear separation between client and server code, shared TypeScript schemas for type safety, and a focus on developer experience through hot reloading and comprehensive error handling.