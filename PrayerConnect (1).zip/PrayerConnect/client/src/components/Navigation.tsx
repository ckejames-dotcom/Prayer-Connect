import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import NotificationCenter from "./NotificationCenter";
import { useAuth } from "@/hooks/useAuth";
import { telemetry } from "@/lib/telemetry";

export default function Navigation() {
  const [location] = useLocation();
  const { isAuthenticated, user } = useAuth();

  const handleNavClick = (from: string, to: string, platform: 'desktop' | 'mobile') => {
    telemetry.trackFeatureUsage('navigation', 'click', {
      from,
      to,
      platform
    });
  };

  // Base navigation items available to all authenticated users
  const baseNavItems = [
    { path: "/", label: "Home", icon: "fas fa-home" },
    { path: "/groups", label: "Groups", icon: "fas fa-users" },
    { path: "/profile", label: "Profile", icon: "fas fa-user" },
  ];

  // Only show admin link to users with admin privileges
  const navItems = (user as any)?.isAdmin 
    ? [...baseNavItems, { path: "/admin", label: "Admin", icon: "fas fa-chart-bar" }]
    : baseNavItems;

  return (
    <>
      {/* Desktop Navigation - Hidden on mobile */}
      <nav className="hidden lg:block fixed top-0 left-0 right-0 z-30 bg-card/90 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
                  <i className="fas fa-praying-hands text-primary-foreground text-lg"></i>
                </div>
                <h1 className="text-xl font-bold text-primary">PrayTogether</h1>
              </div>
              
              <div className="flex items-center space-x-6">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    href={item.path}
                    onClick={() => handleNavClick(location, item.path, 'desktop')}
                    className={cn(
                      "flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors",
                      location === item.path
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    )}
                    data-testid={`nav-${item.label.toLowerCase()}`}
                  >
                    <i className={cn(item.icon, "text-sm")}></i>
                    <span className="font-medium">{item.label}</span>
                  </Link>
                ))}
              </div>
            </div>
            
            {/* Right side - Notifications */}
            {isAuthenticated && (
              <div className="flex items-center">
                <NotificationCenter />
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-30 lg:hidden">
        <div className="flex items-center justify-around h-16">
          {navItems.map((item) => (
            <Link
              key={item.path}
              href={item.path}
              onClick={() => handleNavClick(location, item.path, 'mobile')}
              className={cn(
                "flex flex-col items-center space-y-1 px-3 py-2 min-w-0 flex-1",
                location === item.path
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
              data-testid={`mobile-nav-${item.label.toLowerCase()}`}
            >
              <i className={cn(item.icon, "text-xl")}></i>
              <span className="text-xs font-medium truncate">{item.label}</span>
            </Link>
          ))}
          
          {/* Mobile Notifications */}
          {isAuthenticated && (
            <div className="flex flex-col items-center space-y-1 px-3 py-2 min-w-0 flex-1">
              <NotificationCenter />
              <span className="text-xs font-medium text-muted-foreground">Alerts</span>
            </div>
          )}
        </div>
      </nav>

      {/* Spacer for fixed navigation */}
      <div className="hidden lg:block h-16"></div>
    </>
  );
}
