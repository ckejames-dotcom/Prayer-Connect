import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertPrayerRequestSchema, type InsertPrayerRequest } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { telemetry } from "@/lib/telemetry";
import { z } from "zod";

interface NewPrayerModalProps {
  open: boolean;
  onClose: () => void;
}

const extendedSchema = insertPrayerRequestSchema.extend({
  description: z.string().min(1, "Prayer must be at least 1 character").max(1000, "Prayer must be 1–1000 characters"),
  shareLocation: z.boolean().optional(),
  visibility: z.enum(["public", "private"]).default("public"),
});

type ExtendedFormData = z.infer<typeof extendedSchema>;

export default function NewPrayerModal({ open, onClose }: NewPrayerModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isGettingLocation, setIsGettingLocation] = useState(false);

  const form = useForm<ExtendedFormData>({
    resolver: zodResolver(extendedSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "Other",
      isUrgent: false,
      shareLocation: false,
      visibility: "public",
      latitude: undefined,
      longitude: undefined,
      locationName: "",
    },
  });

  const createPrayerMutation = useMutation({
    mutationFn: async (data: InsertPrayerRequest) => {
      const response = await apiRequest("POST", "/api/prayer-requests", data);
      return response.json();
    },
    onSuccess: (createdPrayer) => {
      const formData = form.getValues();
      telemetry.trackPrayerRequestCreate({
        category: formData.category,
        isUrgent: formData.isUrgent,
        hasLocation: Boolean(formData.latitude && formData.longitude),
        shareLocation: formData.shareLocation,
      });
      toast({
        title: "Prayer Request Created",
        description: "Your prayer request has been shared with the community.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/stats"] });
      form.reset();
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create prayer request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Location Not Available",
        description: "Your browser doesn't support location services.",
        variant: "destructive",
      });
      return;
    }

    setIsGettingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        form.setValue("latitude", latitude.toString());
        form.setValue("longitude", longitude.toString());
        
        // Reverse geocoding would happen here in a real app
        // For now, we'll use a placeholder
        form.setValue("locationName", "Current Location");
        
        setIsGettingLocation(false);
        toast({
          title: "Location Added",
          description: "Your location has been added to the prayer request.",
        });
      },
      (error) => {
        setIsGettingLocation(false);
        toast({
          title: "Location Error",
          description: "Unable to get your location. Please check your permissions.",
          variant: "destructive",
        });
      }
    );
  };

  const onSubmit = (data: ExtendedFormData) => {
    // Remove shareLocation from the data before sending
    const { shareLocation, ...prayerData } = data;
    
    // If location sharing is disabled, remove location data
    if (!shareLocation) {
      prayerData.latitude = undefined;
      prayerData.longitude = undefined;
      prayerData.locationName = undefined;
    }
    
    createPrayerMutation.mutate(prayerData);
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md mx-4" data-testid="new-prayer-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <i className="fas fa-praying-hands text-primary"></i>
            <span>New Prayer Request</span>
          </DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Brief title for your prayer request"
                      {...field}
                      data-testid="prayer-title-input"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="prayer-category-select">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Family">Family</SelectItem>
                      <SelectItem value="Health">Health</SelectItem>
                      <SelectItem value="Work">Work</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      rows={4}
                      placeholder="Share more details about your prayer request..."
                      {...field}
                      data-testid="prayer-description-input"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="visibility"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Who can see this?</FormLabel>
                  <FormControl>
                    <div className="flex items-center gap-4">
                      <label className="flex items-center cursor-pointer">
                        <input
                          type="radio"
                          name="visibility"
                          value="public"
                          checked={field.value === "public"}
                          onChange={() => field.onChange("public")}
                          className="form-radio h-4 w-4 text-primary"
                          data-testid="visibility-public"
                        />
                        <span className="ml-2 text-sm text-foreground">🌐 Public (everyone can pray)</span>
                      </label>

                      <label className="flex items-center cursor-pointer">
                        <input
                          type="radio"
                          name="visibility"
                          value="private"
                          checked={field.value === "private"}
                          onChange={() => field.onChange("private")}
                          className="form-radio h-4 w-4 text-primary"
                          data-testid="visibility-private"
                        />
                        <span className="ml-2 text-sm text-foreground">🔒 Private (only you)</span>
                      </label>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="isUrgent"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value || false}
                      onCheckedChange={field.onChange}
                      data-testid="prayer-urgent-checkbox"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Mark as urgent</FormLabel>
                    <p className="text-sm text-muted-foreground">
                      Urgent prayers will be highlighted and receive priority visibility
                    </p>
                  </div>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="shareLocation"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value || false}
                      onCheckedChange={field.onChange}
                      data-testid="prayer-location-checkbox"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Share my location for nearby prayers</FormLabel>
                    <p className="text-sm text-muted-foreground">
                      Help others in your area find and pray for your request
                    </p>
                  </div>
                </FormItem>
              )}
            />
            
            {form.watch("shareLocation") && (
              <div className="p-3 bg-muted rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Location</span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleGetLocation}
                    disabled={isGettingLocation}
                    data-testid="get-location-button"
                  >
                    {isGettingLocation ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Getting Location...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-location-arrow mr-2"></i>
                        Get Current Location
                      </>
                    )}
                  </Button>
                </div>
                
                {form.watch("locationName") && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <i className="fas fa-map-marker-alt text-primary"></i>
                    <span>{form.watch("locationName")}</span>
                  </div>
                )}
              </div>
            )}
            
            <div className="flex space-x-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleClose}
                className="flex-1"
                data-testid="cancel-prayer-button"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createPrayerMutation.isPending}
                className="flex-1"
                data-testid="submit-prayer-button"
              >
                {createPrayerMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Posting...
                  </>
                ) : (
                  <>
                    <i className="fas fa-praying-hands mr-2"></i>
                    Post Prayer
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
