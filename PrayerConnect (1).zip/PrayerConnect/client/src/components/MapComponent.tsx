import { useEffect, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// For production, this would use a real mapping library like Leaflet or Mapbox
// For now, creating a placeholder component that shows the structure

interface MapMarker {
  id: string;
  latitude: number;
  longitude: number;
  title: string;
  category: string;
  isUrgent: boolean;
  prayerCount: number;
  description?: string;
  author?: {
    firstName: string;
    lastName: string;
  };
}

interface MapComponentProps {
  markers?: MapMarker[];
  center?: [number, number];
  zoom?: number;
  onMarkerClick?: (marker: MapMarker) => void;
}

export default function MapComponent({
  markers = [],
  center = [39.8283, -98.5795], // Center of USA
  zoom = 4,
  onMarkerClick
}: MapComponentProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch detailed prayer information when marker is clicked
  const { data: selectedPrayer } = useQuery({
    queryKey: [`/api/prayer-requests/${selectedMarker?.id}`],
    enabled: !!selectedMarker?.id,
    retry: false,
  });

  // Prayer commitment mutation
  const prayForMutation = useMutation({
    mutationFn: async () => {
      if (!selectedMarker?.id) throw new Error('No prayer selected');
      const response = await apiRequest('POST', `/api/prayer-requests/${selectedMarker.id}/commit`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Prayer commitment made",
        description: "You are now committed to pray for this request.",
      });
      // Invalidate queries to refresh prayer counts
      queryClient.invalidateQueries({ queryKey: ['/api/prayer-requests'] });
      queryClient.invalidateQueries({ queryKey: [`/api/prayer-requests/${selectedMarker?.id}`] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to commit to prayer. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleMarkerClick = (marker: MapMarker) => {
    setSelectedMarker(marker);
    onMarkerClick?.(marker);
  };

  const handleJoinPrayer = () => {
    prayForMutation.mutate();
  };

  const getCategoryColor = (category: string, isUrgent: boolean) => {
    if (isUrgent) return 'bg-destructive';
    
    switch (category) {
      case 'Health': return 'bg-primary';
      case 'Family': return 'bg-secondary';
      case 'Work': return 'bg-accent';
      default: return 'bg-muted-foreground';
    }
  };

  return (
    <div className="relative w-full h-full bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 rounded-lg overflow-hidden" data-testid="map-container">
      {/* Map placeholder - would be replaced with real map */}
      <div ref={mapRef} className="w-full h-full relative">
        {/* Show message when no markers available */}
        {markers.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <i className="fas fa-map-marker-alt text-primary text-6xl mb-4 opacity-20"></i>
              <p className="text-muted-foreground text-lg opacity-40">No prayers with location data available</p>
              <p className="text-sm text-muted-foreground mt-2 opacity-40">Prayer requests need location sharing to appear on the map</p>
            </div>
          </div>
        )}

        {/* Render actual markers */}
        {markers.map((marker) => (
          <div
            key={marker.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
            style={{
              left: `${((marker.longitude + 180) / 360) * 100}%`,
              top: `${((90 - marker.latitude) / 180) * 100}%`,
            }}
            onClick={() => handleMarkerClick(marker)}
          >
            <div className={`w-8 h-8 ${getCategoryColor(marker.category, marker.isUrgent)} rounded-full flex items-center justify-center text-white text-xs font-bold hover:scale-110 transition-transform shadow-lg ${marker.isUrgent ? 'animate-pulse' : ''}`}>
              {marker.prayerCount}
            </div>
          </div>
        ))}

        {/* Center indicator - only show when there are markers */}
        {markers.length > 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center">
              <i className="fas fa-map-marker-alt text-primary text-6xl mb-4 opacity-20"></i>
              <p className="text-muted-foreground text-lg opacity-40">Global Prayer Map</p>
              <p className="text-sm text-muted-foreground mt-2 opacity-40">Click on markers to view prayer details</p>
            </div>
          </div>
        )}
      </div>

      {/* Selected marker popup */}
      {selectedMarker && (
        <Card className="absolute bottom-4 left-4 right-4 z-10" data-testid="marker-popup">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-lg">{selectedMarker.title}</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedMarker(null)}
                data-testid="close-popup-button"
              >
                ×
              </Button>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <Badge 
                variant={selectedMarker.isUrgent ? "destructive" : "default"}
                data-testid="marker-category-badge"
              >
                {selectedMarker.category}
              </Badge>
              {selectedMarker.isUrgent && (
                <Badge variant="destructive" data-testid="urgent-badge">Urgent</Badge>
              )}
            </div>
            {selectedPrayer && (
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                {selectedPrayer.description}
              </p>
            )}
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">
                {selectedMarker.prayerCount} people praying
              </span>
              <Button 
                size="sm" 
                onClick={handleJoinPrayer}
                disabled={prayForMutation.isPending}
                data-testid="join-prayer-button"
              >
                <i className="fas fa-praying-hands mr-2"></i>
                {prayForMutation.isPending ? 'Joining...' : 'Join Prayer'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Map legend */}
      <div className="absolute bottom-4 right-4 bg-card rounded-lg p-3 shadow-lg" data-testid="map-legend">
        <div className="text-xs text-muted-foreground space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-primary rounded-full"></div>
            <span>General</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-destructive rounded-full"></div>
            <span>Urgent</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-accent rounded-full"></div>
            <span>Work</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-secondary rounded-full"></div>
            <span>Family</span>
          </div>
        </div>
      </div>
    </div>
  );
}
