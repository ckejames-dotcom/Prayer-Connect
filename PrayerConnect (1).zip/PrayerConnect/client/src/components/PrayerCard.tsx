import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useAuth } from "@/hooks/useAuth";
import { telemetry } from "@/lib/telemetry";

interface PrayerCardProps {
  prayer: any;
  showActions?: boolean;
}

export default function PrayerCard({ prayer, showActions = false }: PrayerCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const prayForMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/prayer-commitments", {
        prayerRequestId: prayer.id,
      });
      return response.json();
    },
    onSuccess: () => {
      telemetry.trackPrayerCommitment(prayer.id);
      toast({
        title: "Prayer Commitment Added",
        description: "You are now praying for this request.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-requests"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to commit to prayer. You may already be praying for this request.",
        variant: "destructive",
      });
    },
  });

  const markAnsweredMutation = useMutation({
    mutationFn: async (testimony?: string) => {
      const response = await apiRequest("PUT", `/api/prayer-requests/${prayer.id}`, {
        isAnswered: true,
        answeredAt: new Date().toISOString(),
        testimony,
      });
      return response.json();
    },
    onSuccess: () => {
      telemetry.trackFeatureUsage('prayer_answered', 'mark_answered', {
        prayerId: prayer.id,
        category: prayer.category,
        isUrgent: prayer.isUrgent
      });
      toast({
        title: "Prayer Marked as Answered",
        description: "Thank you for sharing this testimony!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-requests"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update prayer request.",
        variant: "destructive",
      });
    },
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Health': return 'bg-primary text-primary-foreground';
      case 'Family': return 'bg-secondary text-secondary-foreground';
      case 'Work': return 'bg-accent text-accent-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const formatAuthorName = (author: any) => {
    if (author?.displayName) {
      return author.displayName;
    }
    if (author?.firstName || author?.lastName) {
      return `${author.firstName || ''} ${author.lastName || ''}`.trim();
    }
    return 'Anonymous';
  };

  const calculateDistance = (lat?: string, lng?: string) => {
    // In a real app, this would calculate actual distance based on user's location
    if (!lat || !lng) return null;
    const distances = ['2.3 miles', '5.1 miles', '12 miles', '45 miles', '127 miles', '500+ miles'];
    return distances[Math.floor(Math.random() * distances.length)];
  };

  const handlePrayFor = () => {
    prayForMutation.mutate();
  };

  const handleMarkAnswered = () => {
    // In a real implementation, this would open a modal for testimony input
    markAnsweredMutation.mutate("Thank you for all your prayers!");
  };

  return (
    <Card className={`prayer-card ${prayer.isAnswered ? 'border-l-4 border-l-accent' : ''}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <img 
              src={prayer.author?.profileImageUrl || `https://ui-avatars.com/api/?name=${formatAuthorName(prayer.author)}&background=random`}
              alt="Prayer requester" 
              className="w-10 h-10 rounded-full object-cover"
            />
            <div>
              <p className="font-medium">{formatAuthorName(prayer.author)}</p>
              <p className="text-sm text-muted-foreground">
                {prayer.locationName || 'Location not shared'} • {new Date(prayer.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className={getCategoryColor(prayer.category)}>
              {prayer.category}
            </Badge>
            {prayer.isUrgent && (
              <Badge variant="destructive">Urgent</Badge>
            )}
            {prayer.isAnswered && (
              <Badge className="bg-accent text-accent-foreground">ANSWERED</Badge>
            )}
          </div>
        </div>
        
        <h3 className="font-semibold text-lg mb-2">{prayer.title}</h3>
        <p className="text-muted-foreground mb-4">{prayer.description}</p>
        
        {prayer.isAnswered && prayer.testimony && (
          <div className="bg-accent/10 p-3 rounded-lg border-l-2 border-l-accent mb-4">
            <p className="text-sm font-medium text-accent mb-1">Testimony:</p>
            <p className="text-sm">{prayer.testimony}</p>
          </div>
        )}
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            {prayer.isAnswered ? (
              <div className="flex items-center space-x-2 text-accent">
                <i className="fas fa-check-circle"></i>
                <span className="font-medium">Answered Prayer</span>
                <span className="text-sm">({prayer.prayerCount || 0} prayed)</span>
              </div>
            ) : (
              <Button 
                variant="ghost" 
                onClick={handlePrayFor}
                disabled={prayForMutation.isPending}
                className="flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors p-0"
                data-testid={`pray-button-${prayer.id}`}
              >
                <i className="fas fa-praying-hands"></i>
                <span className="font-medium">
                  {prayForMutation.isPending ? "Praying..." : "Pray"}
                </span>
                <span className="text-sm">({prayer.prayerCount || 0})</span>
              </Button>
            )}
            
            <Button 
              variant="ghost" 
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors p-0"
              data-testid={`share-button-${prayer.id}`}
            >
              <i className="fas fa-share"></i>
              <span>Share</span>
            </Button>
            
            {showActions && (user as any)?.id === prayer.authorId && !prayer.isAnswered && (
              <Button 
                variant="ghost" 
                onClick={handleMarkAnswered}
                disabled={markAnsweredMutation.isPending}
                className="flex items-center space-x-2 text-accent hover:text-accent/80 transition-colors p-0"
                data-testid={`mark-answered-${prayer.id}`}
              >
                <i className="fas fa-check-circle"></i>
                <span>Mark Answered</span>
              </Button>
            )}
          </div>
          
          <div className="text-sm text-muted-foreground flex items-center">
            <i className="fas fa-map-marker-alt mr-1"></i>
            <span>{calculateDistance(prayer.latitude, prayer.longitude) || 'Distance unknown'}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
