import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

interface GroupDetailModalProps {
  open: boolean;
  onClose: () => void;
  groupId: string | null;
}

export default function GroupDetailModal({ open, onClose, groupId }: GroupDetailModalProps) {
  const { toast } = useToast();

  // Fetch group details
  const { data: group, isLoading } = useQuery({
    queryKey: [`/api/prayer-groups/${groupId}`],
    enabled: Boolean(groupId),
    retry: false,
  });

  // Fetch group members
  const { data: members, isLoading: membersLoading } = useQuery({
    queryKey: [`/api/prayer-groups/${groupId}/members`],
    enabled: Boolean(groupId),
    retry: false,
  });

  if (!groupId) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl" data-testid="group-detail-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <i className="fas fa-users text-primary"></i>
            <span>{isLoading ? "Loading..." : (group as any)?.name || "Group Details"}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="w-full h-6" />
              <Skeleton className="w-full h-20" />
              <Skeleton className="w-full h-12" />
            </div>
          ) : group ? (
            <>
              {/* Group Info */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold">{(group as any)?.name}</h3>
                  <div className="flex items-center space-x-2">
                    {(group as any)?.isPrivate && (
                      <Badge variant="outline">
                        <i className="fas fa-lock mr-1"></i>
                        Private
                      </Badge>
                    )}
                    <Badge variant="secondary">
                      {(members as any)?.length || 0} members
                    </Badge>
                  </div>
                </div>

                {(group as any)?.description && (
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-muted-foreground">{(group as any)?.description}</p>
                  </div>
                )}

                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <span>
                    <i className="fas fa-calendar mr-1"></i>
                    Created {new Date((group as any)?.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>

              {/* Members List */}
              <div>
                <h4 className="font-semibold mb-3">Members</h4>
                {membersLoading ? (
                  <div className="space-y-2">
                    {[1, 2, 3].map(i => (
                      <Skeleton key={i} className="w-full h-12" />
                    ))}
                  </div>
                ) : (members as any) && (members as any).length > 0 ? (
                  <div className="space-y-3 max-h-48 overflow-y-auto">
                    {(members as any).map((member: any) => (
                      <div key={member.id} className="flex items-center space-x-3 p-2 hover:bg-muted/50 rounded">
                        <img 
                          src={member.user?.profileImageUrl || `https://ui-avatars.com/api/?name=${member.user?.firstName || 'U'}&background=random`}
                          alt={`${member.user?.firstName || 'User'} profile`} 
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <p className="font-medium text-sm">
                            {member.user?.firstName || member.user?.lastName 
                              ? `${member.user?.firstName || ''} ${member.user?.lastName || ''}`.trim()
                              : member.user?.email?.split('@')[0] || 'User'
                            }
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Joined {new Date(member.joinedAt).toLocaleDateString()}
                          </p>
                        </div>
                        {member.role === 'admin' && (
                          <Badge variant="outline" className="text-xs">
                            Admin
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No members found
                  </p>
                )}
              </div>

              {/* Actions */}
              <div className="flex justify-end space-x-3 pt-4 border-t">
                <Button variant="outline" onClick={onClose} data-testid="close-group-detail">
                  Close
                </Button>
                <Button 
                  onClick={() => {
                    toast({
                      title: "Coming Soon",
                      description: "Group management features will be available soon.",
                    });
                  }}
                  data-testid="manage-group"
                >
                  <i className="fas fa-cog mr-2"></i>
                  Manage Group
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <i className="fas fa-exclamation-triangle text-muted-foreground text-4xl mb-4"></i>
              <h3 className="text-lg font-semibold mb-2">Group not found</h3>
              <p className="text-muted-foreground">This group may have been deleted or made private.</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}