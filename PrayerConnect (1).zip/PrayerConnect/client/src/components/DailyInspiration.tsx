const quotes = [
  '"The Lord is close to the brokenhearted." – Psalm 34:18',
  '"Cast all your anxiety on Him because He cares for you." – 1 Peter 5:7',
  '"Pray without ceasing." – 1 Thessalonians 5:17',
  '"Let your faith be bigger than your fear."',
  '"When you can\'t put your prayer into words, God hears your heart."',
  '"Be still and know that I am God." – Psalm 46:10',
  '"For I know the plans I have for you." – Jeremiah 29:11',
  '"The prayer of a righteous person is powerful and effective." – James 5:16'
];

const DailyInspiration = () => {
  const today = new Date().getDate();
  const quote = quotes[today % quotes.length];

  return (
    <div className="bg-white dark:bg-card shadow-md rounded-xl p-4 mb-6 text-center" data-testid="daily-inspiration">
      <p className="text-indigo-700 dark:text-indigo-400 italic font-medium">{quote}</p>
    </div>
  );
};

export default DailyInspiration;