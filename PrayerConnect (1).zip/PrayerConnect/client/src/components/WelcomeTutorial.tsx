import { useEffect, useState } from "react";

const WelcomeTutorial = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const hasSeen = localStorage.getItem("hasSeenTutorial");
    if (!hasSeen) {
      setShow(true);
    }
  }, []);

  const dismiss = () => {
    localStorage.setItem("hasSeenTutorial", "true");
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50" data-testid="welcome-tutorial">
      <div className="bg-white dark:bg-card rounded-2xl p-6 max-w-md w-full shadow-lg">
        <h2 className="text-xl font-bold mb-4 text-center text-foreground">Welcome to PrayTogether 🙏</h2>
        <ul className="list-disc list-inside text-muted-foreground space-y-2 mb-4">
          <li>Submit a prayer request to ask for support</li>
          <li>See what others are praying about in the feed</li>
          <li>Tap "I Prayed" to show support</li>
          <li>Track answered prayers in your profile</li>
        </ul>
        <button
          onClick={dismiss}
          className="mt-4 bg-primary text-primary-foreground px-4 py-2 rounded-lg w-full hover:bg-primary/90 transition"
          data-testid="dismiss-tutorial"
        >
          Got it!
        </button>
      </div>
    </div>
  );
};

export default WelcomeTutorial;