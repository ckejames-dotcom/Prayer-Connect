import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface NotificationPreferences {
  id: string;
  userId: string;
  enableUrgentPrayers: boolean;
  enableGroupUpdates: boolean;
  enablePrayerAnswered: boolean;
  enableNewGroupMembers: boolean;
  enablePrayerCommitments: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function NotificationPreferences() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSaving, setIsSaving] = useState(false);

  const { data: preferences, isLoading } = useQuery<NotificationPreferences>({
    queryKey: ['/api/notification-preferences'],
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (updatedPreferences: Partial<NotificationPreferences>) => {
      const response = await fetch('/api/notification-preferences', {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(updatedPreferences),
      });

      if (!response.ok) {
        throw new Error('Failed to update preferences');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notification-preferences'] });
      toast({
        title: "Preferences updated",
        description: "Your notification preferences have been saved.",
      });
    },
    onError: (error) => {
      console.error('Error updating preferences:', error);
      toast({
        title: "Error",
        description: "Failed to update notification preferences. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSaving(false);
    },
  });

  const handlePreferenceChange = async (key: keyof NotificationPreferences, value: boolean) => {
    if (!preferences) return;
    
    setIsSaving(true);
    const updatedPreferences = {
      ...preferences,
      [key]: value,
    };
    
    updatePreferencesMutation.mutate(updatedPreferences);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="animate-pulse space-y-3">
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-4 bg-muted rounded w-1/2"></div>
              <div className="h-4 bg-muted rounded w-2/3"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!preferences) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Failed to load notification preferences.</p>
        </CardContent>
      </Card>
    );
  }

  const preferenceItems = [
    {
      key: 'enableUrgentPrayers' as const,
      title: 'Urgent Prayer Alerts',
      description: 'Receive immediate notifications for urgent prayer requests near you',
      icon: '🚨',
    },
    {
      key: 'enableGroupUpdates' as const,
      title: 'Group Updates',
      description: 'Get notified about important updates in your prayer groups',
      icon: '👥',
    },
    {
      key: 'enablePrayerAnswered' as const,
      title: 'Answered Prayers',
      description: 'Be notified when prayers you committed to are marked as answered',
      icon: '🙏',
    },
    {
      key: 'enableNewGroupMembers' as const,
      title: 'New Group Members',
      description: 'Know when someone joins your prayer groups',
      icon: '👋',
    },
    {
      key: 'enablePrayerCommitments' as const,
      title: 'Prayer Commitments',
      description: 'Get notified when someone commits to pray for your requests',
      icon: '🤝',
    },
  ];

  return (
    <Card data-testid="notification-preferences">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <i className="fas fa-bell text-primary"></i>
          Notification Preferences
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Choose which types of notifications you'd like to receive. Changes are saved automatically.
        </p>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-6">
          {preferenceItems.map((item, index) => (
            <div key={item.key}>
              <div className="flex items-center justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <div className="text-lg mt-1">{item.icon}</div>
                  <div className="space-y-1 flex-1">
                    <Label 
                      htmlFor={item.key}
                      className="text-sm font-medium"
                    >
                      {item.title}
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </div>
                
                <Switch
                  id={item.key}
                  checked={preferences[item.key]}
                  onCheckedChange={(checked) => handlePreferenceChange(item.key, checked)}
                  disabled={isSaving}
                  data-testid={`switch-${item.key}`}
                />
              </div>
              
              {index < preferenceItems.length - 1 && (
                <Separator className="mt-6" />
              )}
            </div>
          ))}
        </div>
        
        <Separator className="my-6" />
        
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <i className="fas fa-info-circle"></i>
            <span>Real-time notifications require an active internet connection</span>
          </div>
          
          {isSaving && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
              <span>Saving...</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}