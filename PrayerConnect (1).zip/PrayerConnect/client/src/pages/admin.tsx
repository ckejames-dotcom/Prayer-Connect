import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import usePageTracking from "@/hooks/usePageTracking";
import { Users, MessageSquare, AlertTriangle, CheckCircle, Heart, UsersIcon, TrendingUp, UserPlus, Shield, Flag, Activity, AlertCircle, Eye, MapPin, Calendar } from "lucide-react";
import { format } from "date-fns";
import { useState } from "react";

interface AdminStats {
  totalUsers: number;
  totalPrayerRequests: number;
  totalUrgentPrayers: number;
  totalAnsweredPrayers: number;
  totalCommitments: number;
  totalGroups: number;
  activeUsersLastWeek: number;
  newUsersThisWeek: number;
  pendingModerationCount: number;
  flaggedPrayersCount: number;
}

interface PrayerRequestDetails {
  id: string;
  title: string;
  description: string;
  category: string;
  isUrgent: boolean;
  isAnswered: boolean;
  answeredAt?: string;
  testimony?: string;
  locationName: string;
  latitude?: string;
  longitude?: string;
  moderationStatus: string;
  moderatedBy?: string;
  moderatedAt?: string;
  moderationReason?: string;
  flaggedCount: number;
  viewCount: number;
  createdAt: string;
  updatedAt: string;
  author: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  moderator?: {
    id: string;
    firstName: string;
    lastName: string;
  };
  commitmentCount: number;
  flagCount?: number;
}

interface UserActivity {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  createdAt: string;
  prayerRequestCount: number;
  commitmentCount: number;
  groupCount: number;
}

interface AdminAction {
  id: string;
  adminUserId: string;
  action: string;
  targetType: string;
  targetId: string;
  details?: any;
  createdAt: string;
  adminUser: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
}

interface PrayerRequestFlag {
  id: string;
  prayerRequestId: string;
  flaggerUserId: string;
  reason: string;
  details?: string;
  status: string;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
  flaggerUser: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
}

interface FrontendAnalytics {
  totalEvents: number;
  uniqueUsers: number;
  popularPages: { path: string; count: number }[];
  errorCount: number;
  featureUsage: { feature: string; count: number }[];
}

interface FrontendError {
  id: string;
  eventType: string;
  userId?: string;
  sessionId?: string;
  pagePath?: string;
  userAgent?: string;
  eventData?: any;
  createdAt: string;
}

export default function AdminPage() {
  const [selectedPrayerId, setSelectedPrayerId] = useState<string | null>(null);
  const [moderationStatus, setModerationStatus] = useState<string>('');
  const [moderationReason, setModerationReason] = useState<string>('');
  const [showModerationDialog, setShowModerationDialog] = useState(false);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Track page views
  usePageTracking();

  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ['/api/admin/stats'],
  });

  const { data: prayerRequests, isLoading: prayerRequestsLoading } = useQuery<PrayerRequestDetails[]>({
    queryKey: ['/api/admin/prayer-requests'],
  });

  const { data: users, isLoading: usersLoading } = useQuery<UserActivity[]>({
    queryKey: ['/api/admin/users'],
  });

  const { data: adminActions, isLoading: actionsLoading } = useQuery<AdminAction[]>({
    queryKey: ['/api/admin/actions'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: frontendAnalytics, isLoading: analyticsLoading } = useQuery<FrontendAnalytics>({
    queryKey: ['/api/admin/analytics/frontend'],
  });

  const { data: frontendErrors, isLoading: errorsLoading } = useQuery<FrontendError[]>({
    queryKey: ['/api/admin/errors/frontend'],
    refetchInterval: 60000, // Refresh every minute
  });

  // Moderation mutation
  const moderationMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: { moderationStatus: string; moderationReason?: string } }) => {
      return await apiRequest(`/api/admin/prayer-requests/${id}/moderation`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/prayer-requests'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/actions'] });
      toast({
        title: "Moderation Updated",
        description: "Prayer request moderation status has been updated.",
      });
      setShowModerationDialog(false);
      setModerationReason('');
      setModerationStatus('');
      setSelectedPrayerId(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update moderation status",
        variant: "destructive",
      });
    },
  });

  const handleModeration = (prayerId: string) => {
    setSelectedPrayerId(prayerId);
    setShowModerationDialog(true);
  };

  const submitModeration = () => {
    if (!selectedPrayerId || !moderationStatus) return;
    
    moderationMutation.mutate({
      id: selectedPrayerId,
      data: {
        moderationStatus,
        moderationReason: moderationReason || undefined,
      },
    });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'approved':
        return 'default';
      case 'rejected':
        return 'destructive';
      case 'pending':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const statsCards = [
    {
      title: "Total Users",
      value: stats?.totalUsers || 0,
      icon: Users,
      description: "Registered users",
      color: "text-blue-600"
    },
    {
      title: "Prayer Requests",
      value: stats?.totalPrayerRequests || 0,
      icon: MessageSquare,
      description: "Total requests posted",
      color: "text-green-600"
    },
    {
      title: "Urgent Prayers",
      value: stats?.totalUrgentPrayers || 0,
      icon: AlertTriangle,
      description: "Marked as urgent",
      color: "text-red-600"
    },
    {
      title: "Answered Prayers",
      value: stats?.totalAnsweredPrayers || 0,
      icon: CheckCircle,
      description: "Marked as answered",
      color: "text-emerald-600"
    },
    {
      title: "Prayer Commitments",
      value: stats?.totalCommitments || 0,
      icon: Heart,
      description: "People praying for others",
      color: "text-pink-600"
    },
    {
      title: "Prayer Groups",
      value: stats?.totalGroups || 0,
      icon: UsersIcon,
      description: "Active groups",
      color: "text-purple-600"
    },
    {
      title: "Pending Moderation",
      value: stats?.pendingModerationCount || 0,
      icon: Shield,
      description: "Awaiting review",
      color: "text-yellow-600"
    },
    {
      title: "Flagged Prayers",
      value: stats?.flaggedPrayersCount || 0,
      icon: Flag,
      description: "User reports",
      color: "text-red-500"
    },
    {
      title: "Active Users (7d)",
      value: stats?.activeUsersLastWeek || 0,
      icon: TrendingUp,
      description: "Users active this week",
      color: "text-orange-600"
    },
    {
      title: "New Users (7d)",
      value: stats?.newUsersThisWeek || 0,
      icon: UserPlus,
      description: "New registrations",
      color: "text-indigo-600"
    },
  ];

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-8"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2" data-testid="admin-title">
            Admin Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Monitor prayer requests, user activity, and app analytics
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          {statsCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-300">
                    {stat.title}
                  </CardTitle>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-gray-900 dark:text-white" data-testid={`stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                    {stat.value.toLocaleString()}
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {stat.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Enhanced Admin Dashboard Tabs */}
        <Tabs defaultValue="prayers" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="prayers" data-testid="tab-prayers">Prayer Requests</TabsTrigger>
            <TabsTrigger value="moderation" data-testid="tab-moderation">Moderation</TabsTrigger>
            <TabsTrigger value="analytics" data-testid="tab-analytics">Analytics</TabsTrigger>
            <TabsTrigger value="actions" data-testid="tab-actions">Admin Actions</TabsTrigger>
            <TabsTrigger value="users" data-testid="tab-users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="prayers" className="space-y-4">
            <Card className="bg-white dark:bg-gray-800">
              <CardHeader>
                <CardTitle>All Prayer Requests</CardTitle>
                <CardDescription>
                  Recent prayer requests with author details, engagement, and moderation status
                </CardDescription>
              </CardHeader>
              <CardContent>
                {prayerRequestsLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                    ))}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Title</TableHead>
                          <TableHead>Author</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Moderation</TableHead>
                          <TableHead>Flags</TableHead>
                          <TableHead>Commitments</TableHead>
                          <TableHead>Views</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {prayerRequests?.map((prayer) => (
                          <TableRow key={prayer.id} data-testid={`prayer-row-${prayer.id}`}>
                            <TableCell className="font-medium">
                              <div className="max-w-xs">
                                <div className="truncate">{prayer.title}</div>
                                <div className="text-sm text-gray-500 dark:text-gray-400 truncate">
                                  {prayer.description}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div>
                                <div className="font-medium">
                                  {prayer.author.firstName} {prayer.author.lastName}
                                </div>
                                <div className="text-sm text-gray-500 dark:text-gray-400">
                                  {prayer.author.email}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{prayer.category}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1 flex-wrap">
                                {prayer.isUrgent && (
                                  <Badge variant="destructive" className="text-xs">
                                    Urgent
                                  </Badge>
                                )}
                                {prayer.isAnswered && (
                                  <Badge variant="default" className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                                    Answered
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={getStatusBadgeVariant(prayer.moderationStatus)} className="text-xs" data-testid={`moderation-status-${prayer.id}`}>
                                {prayer.moderationStatus}
                              </Badge>
                              {prayer.moderator && (
                                <div className="text-xs text-gray-500 mt-1">
                                  by {prayer.moderator.firstName} {prayer.moderator.lastName}
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                {prayer.flaggedCount > 0 && (
                                  <Flag className="h-4 w-4 text-red-500" />
                                )}
                                <span className="text-sm font-medium" data-testid={`flag-count-${prayer.id}`}>
                                  {prayer.flaggedCount}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm font-medium" data-testid={`commitment-count-${prayer.id}`}>
                                {prayer.commitmentCount}
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Eye className="h-4 w-4 text-gray-500" />
                                <span className="text-sm font-medium">
                                  {prayer.viewCount}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                {prayer.latitude && prayer.longitude && (
                                  <MapPin className="h-4 w-4 text-gray-500" />
                                )}
                                <span className="text-sm text-gray-500 dark:text-gray-400">
                                  {prayer.locationName || 'Not specified'}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm text-gray-500 dark:text-gray-400">
                                {format(new Date(prayer.createdAt), 'MMM d, yyyy')}
                              </span>
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleModeration(prayer.id)}
                                data-testid={`moderate-btn-${prayer.id}`}
                              >
                                <Shield className="h-4 w-4 mr-1" />
                                Moderate
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="moderation" className="space-y-4">
            <Card className="bg-white dark:bg-gray-800">
              <CardHeader>
                <CardTitle>Moderation Queue</CardTitle>
                <CardDescription>
                  Review prayer requests that require moderation attention
                </CardDescription>
              </CardHeader>
              <CardContent>
                {prayerRequestsLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="h-20 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {prayerRequests?.filter(prayer => 
                      prayer.moderationStatus === 'pending' || prayer.flaggedCount > 0
                    ).map((prayer) => (
                      <Alert key={prayer.id} className="border-l-4 border-l-yellow-500">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle className="flex justify-between items-center">
                          <span>{prayer.title}</span>
                          <div className="flex gap-2">
                            <Badge variant={getStatusBadgeVariant(prayer.moderationStatus)}>
                              {prayer.moderationStatus}
                            </Badge>
                            {prayer.flaggedCount > 0 && (
                              <Badge variant="destructive" data-testid={`flag-badge-${prayer.id}`}>
                                {prayer.flaggedCount} flags
                              </Badge>
                            )}
                          </div>
                        </AlertTitle>
                        <AlertDescription className="mt-2 space-y-2">
                          <p className="text-sm">{prayer.description}</p>
                          <div className="flex justify-between items-center">
                            <div className="text-xs text-gray-500">
                              By {prayer.author.firstName} {prayer.author.lastName} • {format(new Date(prayer.createdAt), 'MMM d, yyyy')}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleModeration(prayer.id)}
                              data-testid={`review-moderation-${prayer.id}`}
                            >
                              Review
                            </Button>
                          </div>
                        </AlertDescription>
                      </Alert>
                    ))}
                    {prayerRequests?.filter(prayer => 
                      prayer.moderationStatus === 'pending' || prayer.flaggedCount > 0
                    ).length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No items require moderation at this time</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white dark:bg-gray-800">
                <CardHeader>
                  <CardTitle>Frontend Analytics</CardTitle>
                  <CardDescription>
                    User behavior and app usage metrics
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {analyticsLoading ? (
                    <div className="space-y-3">
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600" data-testid="total-events-count">
                            {frontendAnalytics?.totalEvents?.toLocaleString() || 0}
                          </div>
                          <div className="text-sm text-gray-500">Total Events</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600" data-testid="unique-users-count">
                            {frontendAnalytics?.uniqueUsers?.toLocaleString() || 0}
                          </div>
                          <div className="text-sm text-gray-500">Unique Users</div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-medium mb-2">Popular Pages</h4>
                        <div className="space-y-1">
                          {frontendAnalytics?.popularPages?.slice(0, 5).map((page, i) => (
                            <div key={i} className="flex justify-between text-sm">
                              <span className="truncate">{page.path}</span>
                              <span className="text-gray-500">{page.count}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2">Feature Usage</h4>
                        <div className="space-y-1">
                          {frontendAnalytics?.featureUsage?.slice(0, 5).map((feature, i) => (
                            <div key={i} className="flex justify-between text-sm">
                              <span className="truncate">{feature.feature}</span>
                              <span className="text-gray-500">{feature.count}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-white dark:bg-gray-800">
                <CardHeader>
                  <CardTitle>Error Monitoring</CardTitle>
                  <CardDescription>
                    Recent frontend errors and issues
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {errorsLoading ? (
                    <div className="space-y-3">
                      <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                      <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                      <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="text-center mb-4">
                        <div className="text-2xl font-bold text-red-600" data-testid="total-errors-count">
                          {frontendAnalytics?.errorCount?.toLocaleString() || 0}
                        </div>
                        <div className="text-sm text-gray-500">Total Errors</div>
                      </div>
                      
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {frontendErrors?.slice(0, 10).map((error) => (
                          <div key={error.id} className="p-2 bg-red-50 dark:bg-red-900/20 rounded text-sm" data-testid={`frontend-error-${error.id}`}>
                            <div className="font-medium text-red-800 dark:text-red-300">
                              {error.eventData?.message || 'Unknown error'}
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {error.pagePath} • {format(new Date(error.createdAt), 'MMM d, HH:mm')}
                            </div>
                          </div>
                        ))}
                        {frontendErrors?.length === 0 && (
                          <div className="text-center py-4 text-gray-500">
                            <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                            <p>No recent errors detected</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="actions" className="space-y-4">
            <Card className="bg-white dark:bg-gray-800">
              <CardHeader>
                <CardTitle>Admin Action History</CardTitle>
                <CardDescription>
                  Recent moderation actions and administrative activities
                </CardDescription>
              </CardHeader>
              <CardContent>
                {actionsLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {adminActions?.map((action) => (
                      <div key={action.id} className="p-3 border rounded-lg bg-gray-50 dark:bg-gray-700" data-testid={`admin-action-${action.id}`}>
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">
                              {action.adminUser.firstName} {action.adminUser.lastName}
                            </div>
                            <div className="text-sm text-gray-500">
                              {action.action.replace('_', ' ')} • {action.targetType}
                            </div>
                            {action.details && (
                              <div className="text-xs text-gray-400 mt-1">
                                {JSON.stringify(action.details)}
                              </div>
                            )}
                          </div>
                          <div className="text-xs text-gray-500">
                            <Calendar className="h-3 w-3 inline mr-1" />
                            {format(new Date(action.createdAt), 'MMM d, HH:mm')}
                          </div>
                        </div>
                      </div>
                    ))}
                    {adminActions?.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No admin actions recorded yet</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <Card className="bg-white dark:bg-gray-800">
              <CardHeader>
                <CardTitle>User Activity</CardTitle>
                <CardDescription>
                  User engagement metrics and activity levels
                </CardDescription>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                    ))}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>User</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Prayer Requests</TableHead>
                          <TableHead>Commitments</TableHead>
                          <TableHead>Groups</TableHead>
                          <TableHead>Joined</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users?.map((user) => (
                          <TableRow key={user.id} data-testid={`user-row-${user.id}`}>
                            <TableCell className="font-medium">
                              {user.firstName} {user.lastName}
                            </TableCell>
                            <TableCell>
                              <span className="text-sm text-gray-500 dark:text-gray-400">
                                {user.email}
                              </span>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm font-medium" data-testid={`user-prayer-count-${user.id}`}>
                                {user.prayerRequestCount}
                              </span>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm font-medium" data-testid={`user-commitment-count-${user.id}`}>
                                {user.commitmentCount}
                              </span>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm font-medium" data-testid={`user-group-count-${user.id}`}>
                                {user.groupCount}
                              </span>
                            </TableCell>
                            <TableCell>
                              <span className="text-sm text-gray-500 dark:text-gray-400">
                                {format(new Date(user.createdAt), 'MMM d, yyyy')}
                              </span>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        {/* Moderation Dialog */}
        <Dialog open={showModerationDialog} onOpenChange={setShowModerationDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Moderate Prayer Request</DialogTitle>
              <DialogDescription>
                Review and update the moderation status for this prayer request.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Moderation Status</label>
                <Select value={moderationStatus} onValueChange={setModerationStatus} data-testid="moderation-status-select">
                  <SelectTrigger data-testid="moderation-status-trigger">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved" data-testid="moderation-status-approved">Approved</SelectItem>
                    <SelectItem value="rejected" data-testid="moderation-status-rejected">Rejected</SelectItem>
                    <SelectItem value="pending" data-testid="moderation-status-pending">Pending Review</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium">Reason (Optional)</label>
                <Textarea
                  placeholder="Enter moderation reason..."
                  value={moderationReason}
                  onChange={(e) => setModerationReason(e.target.value)}
                  rows={3}
                  data-testid="moderation-reason-textarea"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowModerationDialog(false)} data-testid="cancel-moderation">
                Cancel
              </Button>
              <Button 
                onClick={submitModeration}
                disabled={!moderationStatus || moderationMutation.isPending}
                data-testid="submit-moderation"
              >
                {moderationMutation.isPending ? 'Updating...' : 'Update Status'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}