import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import MapComponent from "@/components/MapComponent";
import Navigation from "@/components/Navigation";
import { Skeleton } from "@/components/ui/skeleton";

export default function MapPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [showUrgentOnly, setShowUrgentOnly] = useState(false);
  const [searchRadius, setSearchRadius] = useState<number>(50);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);

  // Fetch prayer requests for map
  const buildMapUrl = () => {
    const params = new URLSearchParams();
    if (selectedCategory !== "all") {
      params.append("category", selectedCategory);
    }
    if (showUrgentOnly) {
      params.append("urgent", "true");
    }
    return `/api/prayer-requests${params.toString() ? `?${params.toString()}` : ""}`;
  };

  const { data: prayerRequests, isLoading } = useQuery({
    queryKey: [buildMapUrl()],
    retry: false,
  });

  // Get user's location
  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation([latitude, longitude]);
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  };

  const convertToMapMarkers = (prayers: any[]) => {
    if (!prayers) return [];
    
    const filtered = prayers.filter(prayer => prayer.latitude && prayer.longitude);
    
    const markers = filtered.map(prayer => ({
      id: prayer.id,
      latitude: parseFloat(prayer.latitude),
      longitude: parseFloat(prayer.longitude),
      title: prayer.title,
      category: prayer.category,
      isUrgent: prayer.isUrgent,
      prayerCount: parseInt(prayer.prayerCount) || 0,
    }));
    
    return markers;
  };

  const markers = convertToMapMarkers((prayerRequests && Array.isArray(prayerRequests)) ? prayerRequests : []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-background">
      <Navigation />
      
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold mb-2">Global Prayer Map</h1>
              <p className="text-muted-foreground">Discover prayer requests from around the world</p>
            </div>
            
            {/* Filters */}
            <div className="flex items-center gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Family">Family</SelectItem>
                  <SelectItem value="Health">Health</SelectItem>
                  <SelectItem value="Work">Work</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
              
              <Button
                variant={showUrgentOnly ? "default" : "outline"}
                onClick={() => setShowUrgentOnly(!showUrgentOnly)}
                data-testid="urgent-filter-button"
              >
                <i className="fas fa-exclamation-triangle mr-2"></i>
                Urgent Only
              </Button>
              
              <Button onClick={handleGetLocation} variant="outline" data-testid="location-button">
                <i className="fas fa-location-arrow mr-2"></i>
                My Location
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Map */}
          <div className="lg:col-span-3">
            <Card className="h-[600px]">
              <CardContent className="p-0 h-full">
                {isLoading ? (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <Skeleton className="w-16 h-16 rounded-xl mx-auto mb-4" />
                      <p className="text-muted-foreground">Loading prayer locations...</p>
                    </div>
                  </div>
                ) : (
                  <MapComponent
                    markers={markers}
                    center={userLocation || [39.8283, -98.5795]}
                    zoom={userLocation ? 8 : 4}
                  />
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Sidebar Stats and Info */}
          <div className="space-y-6">
            {/* Map Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Map Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total Prayers</span>
                  <Badge variant="outline" data-testid="total-prayers-count">
                    {markers.length}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Urgent</span>
                  <Badge variant="destructive" data-testid="urgent-prayers-count">
                    {markers.filter(m => m.isUrgent).length}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">This Week</span>
                  <Badge variant="secondary" data-testid="weekly-prayers-count">
                    {markers.length} {/* In real app, would filter by date */}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Category Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {['Family', 'Health', 'Work', 'Other'].map(category => {
                  const count = markers.filter(m => m.category === category).length;
                  return (
                    <div key={category} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${
                          category === 'Health' ? 'bg-primary' :
                          category === 'Family' ? 'bg-secondary' :
                          category === 'Work' ? 'bg-accent' : 'bg-muted-foreground'
                        }`}></div>
                        <span className="text-sm">{category}</span>
                      </div>
                      <Badge variant="outline">{count}</Badge>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Search Radius */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Search Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Search Radius (km)</label>
                  <Input
                    type="number"
                    value={searchRadius}
                    onChange={(e) => setSearchRadius(parseInt(e.target.value) || 50)}
                    min="1"
                    max="1000"
                    data-testid="search-radius-input"
                  />
                </div>
                {userLocation && (
                  <div className="text-sm text-muted-foreground">
                    <i className="fas fa-map-marker-alt mr-1"></i>
                    Location enabled
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Legend */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Legend</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold">
                    #
                  </div>
                  <span className="text-sm">Prayer count</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-destructive rounded-full animate-pulse"></div>
                  <span className="text-sm">Urgent prayers</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-secondary rounded-full"></div>
                  <span className="text-sm">Group prayers</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
