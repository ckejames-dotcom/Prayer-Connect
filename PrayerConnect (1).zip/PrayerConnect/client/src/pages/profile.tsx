import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import Navigation from "@/components/Navigation";
import PrayerCard from "@/components/PrayerCard";
import NotificationPreferences from "@/components/NotificationPreferences";
import EditProfileModal from "@/components/EditProfileModal";
import NewPrayerModal from "@/components/NewPrayerModal";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useEffect } from "react";
import usePageTracking from "@/hooks/usePageTracking";

export default function ProfilePage() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showNewPrayer, setShowNewPrayer] = useState(false);
  
  // Track page views
  usePageTracking();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch user stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/users/stats"],
    retry: false,
  });

  // Fetch user's prayer requests
  const { data: userPrayers, isLoading: prayersLoading } = useQuery({
    queryKey: ["/api/prayer-requests/user"],
    retry: false,
  });

  // Fetch user's prayer commitments
  const { data: commitments, isLoading: commitmentsLoading } = useQuery({
    queryKey: ["/api/prayer-commitments/user"],
    retry: false,
  });

  // Fetch user's groups
  const { data: userGroups, isLoading: groupsLoading } = useQuery({
    queryKey: ["/api/prayer-groups/user"],
    retry: false,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-praying-hands text-primary-foreground text-2xl"></i>
          </div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  const formatUserName = (user: any) => {
    if (user?.firstName || user?.lastName) {
      return `${user.firstName || ''} ${user.lastName || ''}`.trim();
    }
    return user?.email?.split('@')[0] || 'User';
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleEditProfile = () => {
    setShowEditProfile(true);
  };

  const handleCloseEditProfile = () => {
    setShowEditProfile(false);
  };

  const handleViewGroup = (groupId: string) => {
    // Navigate to groups page or open group detail modal
    // For now, we'll redirect to the groups page
    window.location.href = "/groups";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-background">
      <Navigation />
      
      {/* Profile Header */}
      <header className="bg-gradient-to-r from-primary to-secondary">
        <div className="container mx-auto px-4 py-12">
          <div className="flex flex-col md:flex-row items-center gap-6 text-primary-foreground">
            <div className="relative">
              <img 
                src={(user as any)?.profileImageUrl || `https://ui-avatars.com/api/?name=${formatUserName(user)}&background=ffffff&color=333333&size=128`}
                alt="Profile" 
                className="w-32 h-32 rounded-full object-cover border-4 border-primary-foreground/20"
                data-testid="profile-avatar"
              />
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                <i className="fas fa-praying-hands text-accent-foreground text-sm"></i>
              </div>
            </div>
            
            <div className="text-center md:text-left flex-1">
              <h1 className="text-3xl font-bold mb-2" data-testid="profile-name">{formatUserName(user)}</h1>
              <p className="text-primary-foreground/80 mb-4" data-testid="profile-email">{(user as any)?.email}</p>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-md">
                <div className="text-center">
                  <div className="text-2xl font-bold" data-testid="profile-stat-prayers">
                    {statsLoading ? "..." : (stats as any)?.prayerCount || 0}
                  </div>
                  <div className="text-xs text-primary-foreground/70">Prayers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold" data-testid="profile-stat-answered">
                    {statsLoading ? "..." : (stats as any)?.answeredCount || 0}
                  </div>
                  <div className="text-xs text-primary-foreground/70">Answered</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold" data-testid="profile-stat-praying-for">
                    {statsLoading ? "..." : (stats as any)?.prayingForCount || 0}
                  </div>
                  <div className="text-xs text-primary-foreground/70">Praying For</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold" data-testid="profile-stat-groups">
                    {statsLoading ? "..." : (stats as any)?.groupCount || 0}
                  </div>
                  <div className="text-xs text-primary-foreground/70">Groups</div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col gap-2">
              <Button variant="secondary" size="sm" onClick={handleEditProfile} data-testid="edit-profile-button">
                <i className="fas fa-edit mr-2"></i>
                Edit Profile
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout} data-testid="logout-button">
                <i className="fas fa-sign-out-alt mr-2"></i>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="prayers" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="prayers" data-testid="prayers-tab">My Prayers</TabsTrigger>
            <TabsTrigger value="commitments" data-testid="commitments-tab">Praying For</TabsTrigger>
            <TabsTrigger value="groups" data-testid="groups-tab">My Groups</TabsTrigger>
            <TabsTrigger value="answered" data-testid="answered-tab">Answered</TabsTrigger>
            <TabsTrigger value="settings" data-testid="settings-tab">Settings</TabsTrigger>
          </TabsList>
          
          <TabsContent value="prayers" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>My Prayer Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {prayersLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <Skeleton key={i} className="w-full h-32" />
                    ))}
                  </div>
                ) : (userPrayers && Array.isArray(userPrayers) && userPrayers.length > 0) ? (
                  <div className="space-y-4" data-testid="user-prayers-list">
                    {(userPrayers && Array.isArray(userPrayers) ? userPrayers : []).map((prayer: any) => (
                      <PrayerCard key={prayer.id} prayer={prayer} showActions />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <i className="fas fa-praying-hands text-muted-foreground text-4xl mb-4"></i>
                    <h3 className="text-lg font-semibold mb-2">No prayer requests yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Share your first prayer request with the community.
                    </p>
                    <Button onClick={() => setShowNewPrayer(true)} data-testid="create-first-prayer">
                      <i className="fas fa-plus mr-2"></i>
                      Create Prayer Request
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="commitments" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>People I'm Praying For</CardTitle>
              </CardHeader>
              <CardContent>
                {commitmentsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <Skeleton key={i} className="w-full h-32" />
                    ))}
                  </div>
                ) : (commitments && Array.isArray(commitments) && commitments.length > 0) ? (
                  <div className="space-y-4" data-testid="prayer-commitments-list">
                    {(commitments && Array.isArray(commitments) ? commitments : []).map((commitment: any) => (
                      <div key={commitment.id} className="p-4 border rounded-lg">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium mb-1">{commitment.prayerRequest?.title}</h4>
                            <p className="text-sm text-muted-foreground mb-2">
                              Committed to pray on {new Date(commitment.createdAt).toLocaleDateString()}
                            </p>
                            <Badge variant="outline">
                              {commitment.prayerRequest?.category}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            <i className="fas fa-calendar mr-1"></i>
                            {Math.floor((new Date().getTime() - new Date(commitment.createdAt).getTime()) / (1000 * 60 * 60 * 24))} days ago
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <i className="fas fa-hands text-muted-foreground text-4xl mb-4"></i>
                    <h3 className="text-lg font-semibold mb-2">No prayer commitments yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Start praying for others in the community.
                    </p>
                    <Button data-testid="browse-prayers">
                      <i className="fas fa-search mr-2"></i>
                      Browse Prayer Requests
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="groups" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>My Prayer Groups</CardTitle>
              </CardHeader>
              <CardContent>
                {groupsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <Skeleton key={i} className="w-full h-20" />
                    ))}
                  </div>
                ) : (userGroups && Array.isArray(userGroups) && userGroups.length > 0) ? (
                  <div className="grid gap-4" data-testid="user-groups-list">
                    {(userGroups && Array.isArray(userGroups) ? userGroups : []).map((group: any) => (
                      <Card key={group.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-4">
                            <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center flex-shrink-0">
                              <i className="fas fa-users text-white"></i>
                            </div>
                            
                            <div className="flex-1">
                              <div className="flex items-start justify-between mb-2">
                                <h3 className="font-semibold">{group.name}</h3>
                                {group.isPrivate && (
                                  <Badge variant="outline" className="text-xs">
                                    <i className="fas fa-lock mr-1"></i>
                                    Private
                                  </Badge>
                                )}
                              </div>
                              
                              {group.description && (
                                <p className="text-sm text-muted-foreground mb-3">
                                  {group.description}
                                </p>
                              )}
                              
                              <div className="flex items-center justify-between">
                                <div className="text-sm text-muted-foreground">
                                  <i className="fas fa-calendar mr-1"></i>
                                  Joined {new Date(group.createdAt).toLocaleDateString()}
                                </div>
                                <Button variant="outline" size="sm" onClick={() => handleViewGroup(group.id)} data-testid={`view-group-${group.id}`}>
                                  View Group
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <i className="fas fa-users text-muted-foreground text-4xl mb-4"></i>
                    <h3 className="text-lg font-semibold mb-2">No prayer groups joined</h3>
                    <p className="text-muted-foreground mb-4">
                      Connect with others by joining or creating prayer groups.
                    </p>
                    <Button data-testid="browse-groups">
                      <i className="fas fa-search mr-2"></i>
                      Browse Groups
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="answered" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Answered Prayers</CardTitle>
              </CardHeader>
              <CardContent>
                {prayersLoading ? (
                  <div className="space-y-4">
                    {[1, 2].map(i => (
                      <Skeleton key={i} className="w-full h-32" />
                    ))}
                  </div>
                ) : (userPrayers && Array.isArray(userPrayers) && userPrayers.filter((prayer: any) => prayer.isAnswered).length > 0) ? (
                  <div className="space-y-4" data-testid="answered-prayers-list">
                    {(userPrayers && Array.isArray(userPrayers) ? userPrayers : [])
                      .filter((prayer: any) => prayer.isAnswered)
                      .map((prayer: any) => (
                        <div key={prayer.id} className="p-4 border-l-4 border-l-accent bg-accent/5 rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="font-semibold text-lg">{prayer.title}</h3>
                            <Badge className="bg-accent text-accent-foreground">
                              <i className="fas fa-check-circle mr-1"></i>
                              ANSWERED
                            </Badge>
                          </div>
                          
                          <p className="text-muted-foreground mb-3">{prayer.description}</p>
                          
                          {prayer.testimony && (
                            <div className="bg-background p-3 rounded border-l-2 border-l-accent">
                              <p className="text-sm font-medium text-accent mb-1">Testimony:</p>
                              <p className="text-sm">{prayer.testimony}</p>
                            </div>
                          )}
                          
                          <div className="flex items-center justify-between mt-3 text-sm text-muted-foreground">
                            <span>
                              <i className="fas fa-calendar mr-1"></i>
                              Answered on {new Date(prayer.answeredAt).toLocaleDateString()}
                            </span>
                            <span>
                              <i className="fas fa-praying-hands mr-1"></i>
                              {prayer.prayerCount || 0} people prayed
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <i className="fas fa-check-circle text-muted-foreground text-4xl mb-4"></i>
                    <h3 className="text-lg font-semibold mb-2">No answered prayers yet</h3>
                    <p className="text-muted-foreground">
                      When your prayers are answered, mark them here to share your testimony!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="settings" className="mt-6">
            <div className="space-y-6">
              <NotificationPreferences />
              
              {/* Additional settings can be added here in the future */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <i className="fas fa-cog text-primary"></i>
                    Account Settings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between py-4">
                    <div>
                      <h4 className="font-medium">Account Management</h4>
                      <p className="text-sm text-muted-foreground">
                        Manage your account settings and preferences
                      </p>
                    </div>
                    <Button variant="outline" onClick={handleLogout} data-testid="settings-logout-button">
                      <i className="fas fa-sign-out-alt mr-2"></i>
                      Logout
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
      
      {/* Edit Profile Modal */}
      <EditProfileModal
        open={showEditProfile}
        onClose={handleCloseEditProfile}
      />
      
      {/* New Prayer Modal */}
      <NewPrayerModal
        open={showNewPrayer}
        onClose={() => setShowNewPrayer(false)}
      />
    </div>
  );
}
