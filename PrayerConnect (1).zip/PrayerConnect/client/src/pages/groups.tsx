import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import Navigation from "@/components/Navigation";
import GroupDetailModal from "@/components/GroupDetailModal";
import { insertPrayerGroupSchema, type InsertPrayerGroup } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { telemetry } from "@/lib/telemetry";
import usePageTracking from "@/hooks/usePageTracking";

export default function GroupsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [showGroupDetail, setShowGroupDetail] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Track page views
  usePageTracking();

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    if (value.length > 2) {
      telemetry.trackSearch(value, undefined, { context: 'prayer_groups' });
    }
  };

  const form = useForm<InsertPrayerGroup>({
    resolver: zodResolver(insertPrayerGroupSchema),
    defaultValues: {
      name: "",
      description: "",
      isPrivate: false,
    },
  });

  // Fetch public groups
  const { data: publicGroups, isLoading: publicGroupsLoading } = useQuery({
    queryKey: ["/api/prayer-groups"],
    retry: false,
  });

  // Fetch user's groups
  const { data: userGroups, isLoading: userGroupsLoading } = useQuery({
    queryKey: ["/api/prayer-groups/user"],
    retry: false,
  });

  // Create group mutation
  const createGroupMutation = useMutation({
    mutationFn: async (data: InsertPrayerGroup) => {
      const response = await apiRequest("POST", "/api/prayer-groups", data);
      return response.json();
    },
    onSuccess: (createdGroup) => {
      const formData = form.getValues();
      telemetry.trackFeatureUsage('prayer_group', 'create', {
        isPrivate: formData.isPrivate,
        hasDescription: Boolean(formData.description)
      });
      toast({
        title: "Success",
        description: "Prayer group created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-groups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-groups/user"] });
      setShowCreateDialog(false);
      form.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create prayer group. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Join group mutation
  const joinGroupMutation = useMutation({
    mutationFn: async (groupId: string) => {
      const response = await apiRequest("POST", `/api/prayer-groups/${groupId}/join`);
      return { result: response.json(), groupId };
    },
    onSuccess: (data) => {
      telemetry.trackGroupJoin(data.groupId);
      toast({
        title: "Success",
        description: "Joined prayer group successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-groups/user"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to join prayer group. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertPrayerGroup) => {
    createGroupMutation.mutate(data);
  };

  const handleJoinGroup = (groupId: string) => {
    joinGroupMutation.mutate(groupId);
  };

  const handleViewGroup = (groupId: string) => {
    setSelectedGroupId(groupId);
    setShowGroupDetail(true);
  };

  const handleCloseGroupDetail = () => {
    setSelectedGroupId(null);
    setShowGroupDetail(false);
  };

  const filteredPublicGroups = (publicGroups && Array.isArray(publicGroups) ? publicGroups : []).filter((group: any) =>
    group.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    group.description?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-background">
      <Navigation />
      
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold mb-2">Prayer Groups</h1>
              <p className="text-muted-foreground">Join communities united in prayer</p>
            </div>
            
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button data-testid="create-group-button">
                  <i className="fas fa-plus mr-2"></i>
                  Create Group
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Prayer Group</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Group Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Family Prayer Circle" {...field} data-testid="group-name-input" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your prayer group's purpose and focus..."
                              {...field}
                              value={field.value || ""}
                              data-testid="group-description-input"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="isPrivate"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value || false}
                              onCheckedChange={field.onChange}
                              data-testid="group-private-checkbox"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Private Group</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Only invited members can see and join this group
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setShowCreateDialog(false)}
                        data-testid="cancel-create-group"
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={createGroupMutation.isPending}
                        data-testid="submit-create-group"
                      >
                        {createGroupMutation.isPending ? "Creating..." : "Create Group"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* My Groups */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>My Prayer Groups</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {userGroupsLoading ? (
                  <div className="space-y-2">
                    {[1, 2, 3].map(i => (
                      <Skeleton key={i} className="w-full h-16" />
                    ))}
                  </div>
                ) : (userGroups && Array.isArray(userGroups) && userGroups.length > 0) ? (
                  (userGroups && Array.isArray(userGroups) ? userGroups : []).map((group: any) => (
                    <div key={group.id} className="p-3 border rounded-lg hover:bg-muted/50 transition-colors" data-testid={`user-group-${group.id}`}>
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center flex-shrink-0">
                          <i className="fas fa-users text-white text-sm"></i>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{group.name}</h4>
                          <p className="text-xs text-muted-foreground">
                            {group.isPrivate && <i className="fas fa-lock mr-1"></i>}
                            Member since {new Date(group.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleViewGroup(group.id)}
                          data-testid={`view-user-group-${group.id}`}
                        >
                          View
                        </Button>
                      </div>
                      {group.description && (
                        <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                          {group.description}
                        </p>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <i className="fas fa-users text-muted-foreground text-3xl mb-3"></i>
                    <p className="text-sm text-muted-foreground">No groups joined yet</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-3"
                      onClick={() => setShowCreateDialog(true)}
                      data-testid="create-first-group"
                    >
                      Create Your First Group
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Browse Public Groups */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Browse Public Groups</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Input
                      placeholder="Search groups..."
                      value={searchTerm}
                      onChange={(e) => handleSearchChange(e.target.value)}
                      className="w-64"
                      data-testid="search-groups-input"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {publicGroupsLoading ? (
                    <div className="space-y-4">
                      {[1, 2, 3, 4].map(i => (
                        <Card key={i}>
                          <CardContent className="p-4">
                            <div className="flex items-start space-x-4">
                              <Skeleton className="w-12 h-12 rounded-lg" />
                              <div className="flex-1 space-y-2">
                                <Skeleton className="w-1/3 h-5" />
                                <Skeleton className="w-full h-4" />
                                <Skeleton className="w-2/3 h-4" />
                                <Skeleton className="w-1/4 h-8" />
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : filteredPublicGroups.length ? (
                    filteredPublicGroups.map((group: any) => (
                      <Card key={group.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-4">
                            <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center flex-shrink-0">
                              <i className="fas fa-users text-white"></i>
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between mb-2">
                                <h3 className="font-semibold text-lg">{group.name}</h3>
                                <div className="flex items-center space-x-2">
                                  {group.isPrivate && (
                                    <Badge variant="outline" className="text-xs">
                                      <i className="fas fa-lock mr-1"></i>
                                      Private
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              
                              {group.description && (
                                <p className="text-muted-foreground mb-3 line-clamp-2">
                                  {group.description}
                                </p>
                              )}
                              
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                  <span>
                                    <i className="fas fa-users mr-1"></i>
                                    {group.memberCount || 1} members
                                  </span>
                                  <span>
                                    <i className="fas fa-calendar mr-1"></i>
                                    Created {new Date(group.createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                                
                                <Button 
                                  onClick={() => handleJoinGroup(group.id)}
                                  disabled={joinGroupMutation.isPending}
                                  data-testid={`join-group-${group.id}`}
                                >
                                  {joinGroupMutation.isPending ? "Joining..." : "Join Group"}
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <i className="fas fa-search text-muted-foreground text-4xl mb-4"></i>
                      <h3 className="text-lg font-semibold mb-2">
                        {searchTerm ? "No groups found" : "No public groups available"}
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        {searchTerm 
                          ? "Try adjusting your search terms or create a new group."
                          : "Be the first to create a public prayer group for the community."
                        }
                      </p>
                      <Button 
                        onClick={() => setShowCreateDialog(true)}
                        data-testid="create-group-empty-state"
                      >
                        <i className="fas fa-plus mr-2"></i>
                        Create Group
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      {/* Group Detail Modal */}
      <GroupDetailModal
        open={showGroupDetail}
        onClose={handleCloseGroupDetail}
        groupId={selectedGroupId}
      />
    </div>
  );
}
