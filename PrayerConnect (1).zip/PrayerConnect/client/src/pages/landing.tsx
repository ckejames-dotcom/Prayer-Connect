import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
              <i className="fas fa-praying-hands text-primary-foreground text-xl"></i>
            </div>
            <h1 className="text-2xl font-bold text-primary">PrayTogether</h1>
          </div>
          
          <Button onClick={handleLogin} size="lg" data-testid="login-button">
            <i className="fas fa-sign-in-alt mr-2"></i>
            Sign In
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Unite in Prayer Across the Globe
          </h2>
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
            Join a compassionate community where prayer requests are shared, supported, and answered. 
            Connect with believers worldwide through location-based prayer mapping and dedicated prayer groups.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button onClick={handleLogin} size="lg" className="text-lg px-8 py-4" data-testid="hero-login-button">
              <i className="fas fa-praying-hands mr-3"></i>
              Start Praying Together
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-4" data-testid="learn-more-button">
              <i className="fas fa-info-circle mr-3"></i>
              Learn More
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">10k+</div>
              <div className="text-sm text-muted-foreground">Active Prayers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">5k+</div>
              <div className="text-sm text-muted-foreground">Answered</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-accent">100+</div>
              <div className="text-sm text-muted-foreground">Countries</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">50k+</div>
              <div className="text-sm text-muted-foreground">Members</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center mb-12">How PrayTogether Works</h3>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-map-marker-alt text-white text-2xl"></i>
              </div>
              <h4 className="text-xl font-semibold mb-3">Share Your Prayer</h4>
              <p className="text-muted-foreground">
                Post prayer requests with location and category to connect with believers who can relate and pray.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-gradient-to-br from-accent to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-hands text-white text-2xl"></i>
              </div>
              <h4 className="text-xl font-semibold mb-3">Commit to Pray</h4>
              <p className="text-muted-foreground">
                Browse nearby or global prayer requests and commit to pray, joining others in faithful intercession.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="p-8">
              <div className="w-16 h-16 bg-gradient-to-br from-secondary to-pink-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-users text-white text-2xl"></i>
              </div>
              <h4 className="text-xl font-semibold mb-3">Join Prayer Groups</h4>
              <p className="text-muted-foreground">
                Create or join specialized prayer groups for families, churches, or specific causes and needs.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-primary to-secondary py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold text-primary-foreground mb-4">
            Ready to Join Our Prayer Community?
          </h3>
          <p className="text-primary-foreground/90 text-lg mb-8 max-w-2xl mx-auto">
            Experience the power of united prayer. Share your burdens, lift up others, and witness God's faithfulness together.
          </p>
          <Button 
            onClick={handleLogin} 
            size="lg" 
            variant="secondary"
            className="text-lg px-8 py-4"
            data-testid="cta-login-button"
          >
            <i className="fas fa-heart mr-3"></i>
            Join PrayTogether Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <i className="fas fa-praying-hands text-primary-foreground text-sm"></i>
            </div>
            <span className="text-lg font-semibold">PrayTogether</span>
          </div>
          <p className="text-muted-foreground">
            Building bridges of prayer across communities and continents.
          </p>
        </div>
      </footer>
    </div>
  );
}
