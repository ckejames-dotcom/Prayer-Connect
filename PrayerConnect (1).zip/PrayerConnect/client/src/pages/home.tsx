import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import PrayerCard from "@/components/PrayerCard";
import NewPrayerModal from "@/components/NewPrayerModal";
import MapComponent from "@/components/MapComponent";
import Navigation from "@/components/Navigation";
import WelcomeTutorial from "@/components/WelcomeTutorial";
import DailyInspiration from "@/components/DailyInspiration";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useEffect } from "react";
import usePageTracking from "@/hooks/usePageTracking";
import { apiRequest } from "@/lib/queryClient";
import { telemetry } from "@/lib/telemetry";

export default function Home() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isNewPrayerModalOpen, setIsNewPrayerModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  // Track page views
  usePageTracking();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch user stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/users/stats"],
    retry: false,
  });

  // Fetch prayer requests
  const prayerRequestsUrl = selectedCategory !== "all" 
    ? `/api/prayer-requests?category=${selectedCategory}`
    : "/api/prayer-requests";
  
  const { data: prayerRequests, isLoading: prayersLoading } = useQuery({
    queryKey: [prayerRequestsUrl],
    retry: false,
  });

  // Fetch user's groups
  const { data: userGroups, isLoading: groupsLoading } = useQuery({
    queryKey: ["/api/prayer-groups/user"],
    retry: false,
  });

  // Fetch nearby urgent prayers
  const { data: urgentPrayers } = useQuery({
    queryKey: ["/api/prayer-requests?urgent=true&limit=5"],
    retry: false,
  });

  // Prayer commitment mutation for urgent prayers
  const prayForMutation = useMutation({
    mutationFn: async (prayerId: string) => {
      const response = await apiRequest("POST", "/api/prayer-commitments", {
        prayerRequestId: prayerId,
      });
      return response.json();
    },
    onSuccess: (data, prayerId) => {
      telemetry.trackPrayerCommitment(prayerId);
      toast({
        title: "Prayer Commitment Added",
        description: "You are now praying for this request.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/prayer-requests?urgent=true&limit=5"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to commit to prayer. You may already be praying for this request.",
        variant: "destructive",
      });
    },
  });

  const handleJoinUrgentPrayer = (prayerId: string) => {
    prayForMutation.mutate(prayerId);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-praying-hands text-primary-foreground text-2xl"></i>
          </div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  const formatUserName = (user: any) => {
    if (user?.firstName || user?.lastName) {
      return `${user.firstName || ''} ${user.lastName || ''}`.trim();
    }
    return user?.email?.split('@')[0] || 'User';
  };

  return (
    <>
      <WelcomeTutorial />
      <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white dark:from-gray-900 dark:to-background">
      <Navigation />
      
      {/* Header */}
      <header className="sticky top-0 z-40 bg-card/90 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
              <i className="fas fa-praying-hands text-primary-foreground text-lg"></i>
            </div>
            <h1 className="text-xl font-bold text-primary">PrayTogether</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="relative p-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="notifications-button">
              <i className="fas fa-bell text-lg"></i>
              {(urgentPrayers && Array.isArray(urgentPrayers) && urgentPrayers.length > 0) && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
                  {urgentPrayers.length}
                </span>
              )}
            </button>
            
            <div className="flex items-center space-x-2 cursor-pointer" data-testid="user-profile">
              <img 
                src={(user as any)?.profileImageUrl || `https://ui-avatars.com/api/?name=${formatUserName(user)}&background=random`}
                alt="User profile" 
                className="w-8 h-8 rounded-full object-cover"
              />
              <span className="hidden sm:inline font-medium">{formatUserName(user)}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Welcome Greeting */}
        <h1 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-gray-100" data-testid="welcome-greeting">
          Welcome back, {(user as any)?.firstName || "friend"} 🙏
        </h1>
        
        {/* Daily Inspiration */}
        <DailyInspiration />
        
        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">My Prayers</p>
                  {statsLoading ? (
                    <Skeleton className="w-8 h-6" />
                  ) : (
                    <p className="text-2xl font-bold text-primary" data-testid="stat-my-prayers">{(stats as any)?.prayerCount || 0}</p>
                  )}
                </div>
                <i className="fas fa-heart text-primary text-xl"></i>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Answered</p>
                  {statsLoading ? (
                    <Skeleton className="w-8 h-6" />
                  ) : (
                    <p className="text-2xl font-bold text-accent" data-testid="stat-answered">{(stats as any)?.answeredCount || 0}</p>
                  )}
                </div>
                <i className="fas fa-check-circle text-accent text-xl"></i>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Praying For</p>
                  {statsLoading ? (
                    <Skeleton className="w-8 h-6" />
                  ) : (
                    <p className="text-2xl font-bold text-secondary" data-testid="stat-praying-for">{(stats as any)?.prayingForCount || 0}</p>
                  )}
                </div>
                <i className="fas fa-hands text-secondary text-xl"></i>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">My Groups</p>
                  {statsLoading ? (
                    <Skeleton className="w-8 h-6" />
                  ) : (
                    <p className="text-2xl font-bold text-primary" data-testid="stat-my-groups">{(stats as any)?.groupCount || 0}</p>
                  )}
                </div>
                <i className="fas fa-users text-primary text-xl"></i>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-1 gap-6">
          {/* Sidebar - now full width */}
          <div className="space-y-6">
            {/* Urgent Prayers */}
            <Card>
              <div className="p-4 border-b border-border">
                <h3 className="font-semibold text-destructive flex items-center">
                  <i className="fas fa-exclamation-triangle mr-2"></i>
                  Urgent Prayers
                </h3>
              </div>
              
              <div className="p-4 space-y-3">
                {(urgentPrayers && Array.isArray(urgentPrayers) ? urgentPrayers.slice(0, 2) : []).map((prayer: any) => (
                  <div key={prayer.id} className="flex items-start space-x-3 p-3 bg-destructive/5 rounded-lg border-l-4 border-destructive">
                    <div className="w-8 h-8 bg-destructive/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="fas fa-heartbeat text-destructive text-sm"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{prayer.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {prayer.locationName} • {new Date(prayer.createdAt).toLocaleDateString()}
                      </p>
                      <div className="flex items-center mt-2 space-x-2">
                        <span className="text-xs text-destructive font-medium">{prayer.prayerCount || 0} people praying</span>
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          className="text-xs px-2 py-1" 
                          onClick={() => handleJoinUrgentPrayer(prayer.id)}
                          disabled={prayForMutation.isPending}
                          data-testid={`join-urgent-prayer-${prayer.id}`}
                        >
                          {prayForMutation.isPending ? "Joining..." : "Join Prayer"}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                
                {!(urgentPrayers && Array.isArray(urgentPrayers) && urgentPrayers.length > 0) && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No urgent prayers at the moment
                  </p>
                )}
              </div>
              
              <div className="p-4 border-t border-border">
                <Button variant="link" size="sm" className="w-full" data-testid="view-all-urgent">View All Urgent Prayers</Button>
              </div>
            </Card>
            
            {/* My Groups */}
            <Card>
              <div className="p-4 border-b border-border flex items-center justify-between">
                <h3 className="font-semibold">My Prayer Groups</h3>
                <Button variant="ghost" size="sm" data-testid="add-group-button">
                  <i className="fas fa-plus text-sm"></i>
                </Button>
              </div>
              
              <div className="p-4 space-y-3">
                {groupsLoading ? (
                  <div className="space-y-2">
                    <Skeleton className="w-full h-12" />
                    <Skeleton className="w-full h-12" />
                  </div>
                ) : (userGroups && Array.isArray(userGroups) && userGroups.length > 0) ? (
                  (userGroups && Array.isArray(userGroups) ? userGroups.slice(0, 3) : []).map((group: any) => (
                    <div key={group.id} className="flex items-center space-x-3 p-2 hover:bg-muted/50 rounded-lg cursor-pointer" data-testid={`group-${group.id}`}>
                      <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                        <i className="fas fa-users text-white text-sm"></i>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{group.name}</p>
                        <p className="text-xs text-muted-foreground">{group.memberCount || 0} members</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No groups joined yet
                  </p>
                )}
              </div>
            </Card>
          </div>
        </div>
        
        {/* Recent Prayer Requests */}
        <div className="mt-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Recent Prayer Requests</h2>
            <div className="flex items-center space-x-2">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Family">Family</SelectItem>
                  <SelectItem value="Health">Health</SelectItem>
                  <SelectItem value="Work">Work</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid gap-4" data-testid="prayer-requests-list">
            {prayersLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <Skeleton className="w-10 h-10 rounded-full" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="w-1/4 h-4" />
                          <Skeleton className="w-3/4 h-6" />
                          <Skeleton className="w-full h-16" />
                          <Skeleton className="w-1/3 h-4" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (prayerRequests && Array.isArray(prayerRequests) && prayerRequests.length > 0) ? (
              (prayerRequests && Array.isArray(prayerRequests) ? prayerRequests : []).map((prayer: any) => (
                <PrayerCard key={prayer.id} prayer={prayer} />
              ))
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <i className="fas fa-praying-hands text-muted-foreground text-4xl mb-4"></i>
                  <h3 className="text-lg font-semibold mb-2">No prayer requests found</h3>
                  <p className="text-muted-foreground mb-4">Be the first to share a prayer request with the community.</p>
                  <Button onClick={() => setIsNewPrayerModalOpen(true)} data-testid="first-prayer-button">
                    <i className="fas fa-plus mr-2"></i>
                    Post Your First Prayer
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
      
      {/* Floating Action Button */}
      <button
        onClick={() => setIsNewPrayerModalOpen(true)}
        className="fixed bottom-6 right-6 flex items-center gap-2 bg-blue-600 text-white px-4 py-3 rounded-full shadow-lg hover:bg-blue-700 transition z-40"
        data-testid="fab-new-prayer"
      >
        <span className="text-lg">✍️</span>
        <span className="text-base font-medium">Request Prayer</span>
      </button>
      
      {/* New Prayer Modal */}
      <NewPrayerModal 
        open={isNewPrayerModalOpen} 
        onClose={() => setIsNewPrayerModalOpen(false)} 
      />
    </div>
    </>
  );
}
