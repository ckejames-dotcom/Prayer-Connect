import { apiRequest } from './queryClient';
import { nanoid } from 'nanoid';

// Frontend event types based on the schema enum
export type FrontendEventType = 
  | 'page_view'
  | 'prayer_request_create'
  | 'prayer_commitment'
  | 'group_join'
  | 'search'
  | 'map_interaction'
  | 'error'
  | 'feature_usage';

export interface TelemetryEvent {
  eventType: FrontendEventType;
  eventData?: Record<string, any>;
  pagePath?: string;
}

export class TelemetryTracker {
  private static instance: TelemetryTracker;
  private queue: TelemetryEvent[] = [];
  private isFlushingQueue = false;
  private flushTimer: NodeJS.Timeout | null = null;
  private sessionId: string;

  private constructor() {
    // Generate session ID
    this.sessionId = nanoid();
    
    // Flush queue every 5 seconds or when it reaches 10 events
    this.startPeriodicFlush();
    
    // Flush on page unload
    window.addEventListener('beforeunload', () => this.flush());
  }

  static getInstance(): TelemetryTracker {
    if (!TelemetryTracker.instance) {
      TelemetryTracker.instance = new TelemetryTracker();
    }
    return TelemetryTracker.instance;
  }

  track(event: TelemetryEvent): void {
    // Enrich event with session and page data
    const enrichedEvent = {
      sessionId: this.sessionId,
      eventType: event.eventType,
      eventData: event.eventData || {},
      pagePath: event.pagePath || (window.location.pathname + window.location.search),
      userAgent: navigator.userAgent,
    };

    this.queue.push(enrichedEvent);

    // Flush immediately for critical events or when queue is full
    if (event.eventType === 'error' || this.queue.length >= 10) {
      this.flush();
    }
  }

  private startPeriodicFlush(): void {
    this.flushTimer = setInterval(() => {
      if (this.queue.length > 0) {
        this.flush();
      }
    }, 5000);
  }

  private async flush(): Promise<void> {
    if (this.isFlushingQueue || this.queue.length === 0) {
      return;
    }

    this.isFlushingQueue = true;
    const eventsToSend = [...this.queue];
    this.queue = [];

    try {
      // Send events individually to the existing endpoint
      await Promise.all(
        eventsToSend.map(event => 
          apiRequest('POST', '/api/telemetry/event', event)
        )
      );
    } catch (error) {
      console.warn('Failed to send telemetry events:', error);
      // Re-queue events if sending failed
      this.queue.unshift(...eventsToSend);
    } finally {
      this.isFlushingQueue = false;
    }
  }

  // Convenience methods for common event types
  trackPageView(): void {
    this.track({
      eventType: 'page_view',
      eventData: {
        timestamp: new Date().toISOString(),
        referrer: document.referrer,
      }
    });
  }

  trackPrayerRequestCreate(requestData: Record<string, any>): void {
    this.track({
      eventType: 'prayer_request_create',
      eventData: requestData
    });
  }

  trackPrayerCommitment(prayerId: string): void {
    this.track({
      eventType: 'prayer_commitment',
      eventData: { prayerId }
    });
  }

  trackGroupJoin(groupId: string): void {
    this.track({
      eventType: 'group_join',
      eventData: { groupId }
    });
  }

  trackSearch(query: string, resultCount?: number, filters?: Record<string, any>): void {
    this.track({
      eventType: 'search',
      eventData: { query, resultCount, filters }
    });
  }

  trackMapInteraction(action: string, data?: Record<string, any>): void {
    this.track({
      eventType: 'map_interaction',
      eventData: { action, ...data }
    });
  }

  trackError(error: string, context?: string, metadata?: Record<string, any>): void {
    this.track({
      eventType: 'error',
      eventData: { error, context, ...metadata }
    });
  }

  trackFeatureUsage(feature: string, action: string, metadata?: Record<string, any>): void {
    this.track({
      eventType: 'feature_usage',
      eventData: { feature, action, ...metadata }
    });
  }
}

// Export singleton instance
export const telemetry = TelemetryTracker.getInstance();

// Convenience function for quick tracking
export function trackEvent(event: TelemetryEvent): void {
  telemetry.track(event);
}