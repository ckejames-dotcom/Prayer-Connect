import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { telemetry } from '@/lib/telemetry';

export function usePageTracking() {
  const [location] = useLocation();

  useEffect(() => {
    // Track page view when location changes
    telemetry.trackPageView();
  }, [location]);
}

export default usePageTracking;