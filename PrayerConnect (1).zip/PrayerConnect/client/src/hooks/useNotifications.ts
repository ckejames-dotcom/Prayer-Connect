import { useEffect, useState, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';

export interface Notification {
  id: string;
  userId: string;
  type: 'urgent_prayer' | 'group_update' | 'prayer_answered' | 'new_group_member' | 'prayer_commitment';
  title: string;
  message: string;
  isRead: boolean;
  relatedEntityId?: string;
  relatedEntityType?: string;
  createdAt: string;
}

export function useNotifications() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const socketRef = useRef<Socket | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isConnected, setIsConnected] = useState(false);

  // Fetch notifications
  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['/api/notifications'],
    enabled: isAuthenticated,
    refetchOnWindowFocus: false,
  });

  // Fetch unread count
  const { data: unreadCountData } = useQuery({
    queryKey: ['/api/notifications/unread-count'],
    enabled: isAuthenticated,
    refetchInterval: 30000, // Refresh every 30 seconds as fallback
  });

  useEffect(() => {
    if (unreadCountData?.count !== undefined) {
      setUnreadCount(unreadCountData.count);
    }
  }, [unreadCountData]);

  // Initialize WebSocket connection
  useEffect(() => {
    if (!isAuthenticated || !user) return;

    const socket = io({
      autoConnect: true,
      transports: ['websocket', 'polling'],
    });

    socketRef.current = socket;

    socket.on('connect', async () => {
      console.log('Connected to notification service');
      setIsConnected(true);
      
      try {
        // Get WebSocket authentication token from server
        const response = await fetch('/api/auth/ws-token', {
          credentials: 'include',
        });
        
        if (response.ok) {
          const { token } = await response.json();
          console.log('Got WebSocket token, authenticating...');
          socket.emit('authenticate', token);
        } else {
          console.error('Failed to get WebSocket authentication token');
          setIsConnected(false);
          toast({
            title: "Connection Error",
            description: "Failed to authenticate for real-time notifications",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error('Error getting WebSocket token:', error);
        setIsConnected(false);
      }
    });

    socket.on('authenticated', (data) => {
      console.log('WebSocket authentication successful for user:', data.userId);
      setIsConnected(true);
    });

    socket.on('auth_error', (data) => {
      console.error('WebSocket authentication failed:', data.message);
      setIsConnected(false);
      toast({
        title: "Connection Error",
        description: "Failed to establish secure connection for notifications",
        variant: "destructive",
      });
    });

    socket.on('disconnect', () => {
      console.log('Disconnected from notification service');
      setIsConnected(false);
    });

    socket.on('new_notification', (notification: Notification) => {
      console.log('New notification received:', notification);
      
      // Show toast for urgent notifications
      if (notification.type === 'urgent_prayer') {
        toast({
          title: notification.title,
          description: notification.message,
          duration: 8000,
        });
      } else {
        toast({
          title: notification.title,
          description: notification.message,
          duration: 5000,
        });
      }

      // Refresh notifications list
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread-count'] });
    });

    socket.on('unread_count_updated', (data: { count: number }) => {
      console.log('Unread count updated:', data.count);
      setUnreadCount(data.count);
      queryClient.setQueryData(['/api/notifications/unread-count'], { count: data.count });
    });

    socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      setIsConnected(false);
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
      setIsConnected(false);
    };
  }, [isAuthenticated, user, toast, queryClient]);

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'PUT',
        credentials: 'include',
      });

      if (response.ok) {
        // Update local state optimistically
        setUnreadCount(prev => Math.max(0, prev - 1));
        
        // Refresh queries
        queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
        queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread-count'] });
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch('/api/notifications/read-all', {
        method: 'PUT',
        credentials: 'include',
      });

      if (response.ok) {
        setUnreadCount(0);
        queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
        queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread-count'] });
      }
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
    }
  };

  // WebSocket helper methods
  const markNotificationRead = (notificationId: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('mark_notification_read', notificationId);
    } else {
      markAsRead(notificationId);
    }
  };

  const markAllNotificationsRead = () => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('mark_all_notifications_read');
    } else {
      markAllAsRead();
    }
  };

  return {
    notifications,
    unreadCount,
    isLoading,
    isConnected,
    markAsRead: markNotificationRead,
    markAllAsRead: markAllNotificationsRead,
  };
}