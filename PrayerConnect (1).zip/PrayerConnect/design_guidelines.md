# PrayTogether Design Guidelines

## Design Approach
**Reference-Based**: Drawing from Instagram's community engagement patterns and LinkedIn's group features, adapted for spiritual/contemplative atmosphere. Focus on warmth, approachability, and meaningful connections.

## Typography
- **Primary Font**: Inter (via Google Fonts CDN) for clean readability
- **Hierarchy**: 
  - Page Titles: text-3xl font-semibold
  - Section Headers: text-xl font-medium
  - Prayer Titles: text-lg font-medium
  - Body Text: text-base
  - Meta Info: text-sm text-gray-600
  - Timestamps: text-xs text-gray-500

## Layout System
**Spacing Primitives**: Use Tailwind units of 3, 4, 6, 8, 12, 16 (p-3, gap-6, mb-8, etc.)
- **Container**: max-w-6xl mx-auto for main content
- **Card Spacing**: p-6 for prayer cards, p-4 for smaller elements
- **Section Gaps**: space-y-8 for major sections, space-y-4 within cards

## Core Components

### Navigation
Top navigation bar with logo left, search center, profile/notifications right. Sticky positioning. Include: Home, Groups, My Prayers, Answered tabs.

### Prayer Request Card
Rounded-2xl cards with shadow-lg. Structure: Author avatar/name top-left, timestamp top-right, prayer text (max 3 lines visible with "Read more"), category tag (indigo badge), prayer count indicator, "I'll Pray" button bottom.

### Hero Section (Home Feed)
Full-width hero with background image showing hands in prayer circle or peaceful spiritual gathering. Overlay gradient (indigo-900/40 to transparent). Centered white text: "Together in Prayer" headline (text-5xl font-bold) + subheadline. Search bar and "Share Prayer Request" primary button with backdrop-blur-md bg-white/20 treatment.

### Prayer Groups Grid
3-column grid (lg:grid-cols-3 md:grid-cols-2) of group cards. Each card: Cover image top, group name, member count, "Join" or "Joined" button, latest activity snippet.

### Answered Prayers Timeline
Left-aligned timeline with vertical indigo line. Each entry: Small celebration icon, answered prayer text, original request date → answered date, "Praise" button, comment count.

### User Profile Section
Split layout: Left sidebar (profile image, name, prayer stats dashboard - requested/praying for/answered counts in rounded stat cards), Right main area (tabs for Active Prayers, Prayer History, Groups).

### Prayer Commitment Tracker
Circular progress indicators showing weekly prayer commitments. Small cards with prayer recipient name, commitment streak number, "Mark as Prayed" checkbox.

### Icons
Font Awesome (CDN) for: prayer hands, group, calendar, check-circle, heart, comment, bell, search, plus-circle.

## Images

### Hero Image
Large inspirational image (1920x600px) showing diverse hands joined in prayer circle or peaceful meditation scene. Should convey unity and spirituality. Warm, soft lighting essential.

### Group Cover Images
Smaller rectangular images (800x400px) showing thematic content: church gatherings, nature scenes (sunrise/sunset), scripture study groups, etc. Each group needs unique cover.

### Profile Avatars
Circular user photos throughout. Default placeholder: gentle indigo gradient with initials.

### Background Accents
Subtle watermark-style decorative elements: faint dove outlines, olive branches, or abstract spiritual symbols in page backgrounds (very low opacity indigo-100).

## Component Library

### Buttons
- **Primary**: Rounded-full, indigo background, white text, shadow-md
- **Secondary**: Rounded-full, white background, indigo border, indigo text
- **Icon Buttons**: Square with rounded-lg, minimal indigo background on hover
- **Floating Action Button**: Fixed bottom-right, large rounded-full, indigo, "+" icon for new prayer request

### Form Elements
All inputs: rounded-lg borders, indigo focus rings, p-3 padding. Textarea for prayer requests with character counter.

### Modals
Centered overlay with backdrop-blur-sm bg-black/30 background. Modal itself: rounded-2xl, shadow-2xl, max-w-2xl, white background.

### Badges/Tags
Small rounded-full pills for prayer categories: Health, Family, Guidance, Gratitude, etc. Indigo-50 background with indigo-700 text.

### Notification Cards
Toast-style notifications top-right with slide-in animation. Include prayer hand icon, brief message, timestamp.

## Page-Specific Layouts

### Home Feed
Hero section → Filter tabs (All, Following, Groups) → Prayer request cards in single column feed, infinite scroll pattern.

### Groups Page
Hero with "Find Your Prayer Community" → Category filters horizontal scroll → Groups grid → "Create Group" prominent CTA.

### My Prayers Dashboard
Stats overview cards (3-column) → Tabs for Requested/Committed/Answered → Respective card lists.